<div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6">
        <div class="panel panel-bordered">
            <div class="panel-body" style="padding:30px;">
                <div class="dd col-md-3">

