<?php $__env->startComponent($typeForm, get_defined_vars()); ?>
    <button form="post-form"
            formaction="<?php echo e($action); ?>"
            data-novalidate="<?php echo e(var_export($novalidate)); ?>"
            data-turbolinks="<?php echo e(var_export($turbolinks)); ?>"
            <?php if(empty(!$confirm)): ?>onclick="return confirm('<?php echo e($confirm); ?>');"<?php endif; ?>
        <?php call_user_func(function ($attributes) {
                foreach ($attributes as $name => $value) {
                    if (is_null($value)) {
                        continue;
                    }

                    if (is_bool($value) && $value === false) {
                        continue;
                    }
                    if (is_bool($value)) {
                        echo e($name)." ";
                        continue;
                    }

                    if (is_array($value)) {
                        echo json_decode($value)." ";
                        continue;
                    }

                    echo e($name) . '="' . e($value) . '"'." ";
                }
            }, $attributes); ?>>
        <?php if(isset($icon)): ?><i class="<?php echo e($icon); ?> mr-2"></i><?php endif; ?>
        <?php echo e($name ?? ''); ?>

    </button>
<?php if (isset($__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d)): ?>
<?php $component = $__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d; ?>
<?php unset($__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/dev/web/crm/vendor/orchid/platform/resources/views/actions/button.blade.php ENDPATH**/ ?>