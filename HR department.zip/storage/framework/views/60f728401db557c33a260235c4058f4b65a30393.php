<div class="form-group">
    <?php echo e($slot); ?>


    <?php if($errors->has($oldName)): ?>
        <div class="invalid-feedback d-block">
            <small><?php echo e($errors->first($oldName)); ?></small>
        </div>
    <?php elseif(isset($help)): ?>
        <small class="form-text text-muted"><?php echo $help; ?></small>
    <?php endif; ?>
</div>
<?php if(isset($hr)): ?>
    <div class="line line-dashed border-bottom line-lg"></div>
<?php endif; ?>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/partials/fields/clear.blade.php ENDPATH**/ ?>