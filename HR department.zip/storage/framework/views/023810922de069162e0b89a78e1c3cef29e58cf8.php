<?php $__env->startComponent($typeForm, get_defined_vars()); ?>
    <div data-controller="fields--datetime"
         class="input-group"
        <?php call_user_func(function ($attributes) {
                foreach ($attributes as $name => $value) {
                    if (is_null($value)) {
                        continue;
                    }

                    if (is_bool($value) && $value === false) {
                        continue;
                    }
                    if (is_bool($value)) {
                        echo e($name)." ";
                        continue;
                    }

                    if (is_array($value)) {
                        echo json_decode($value)." ";
                        continue;
                    }

                    echo e($name) . '="' . e($value) . '"'." ";
                }
            }, $dataAttributes); ?>>
        <input type="text"
               placeholder="<?php echo e($placeholder ?? ''); ?>"
               <?php call_user_func(function ($attributes) {
                foreach ($attributes as $name => $value) {
                    if (is_null($value)) {
                        continue;
                    }

                    if (is_bool($value) && $value === false) {
                        continue;
                    }
                    if (is_bool($value)) {
                        echo e($name)." ";
                        continue;
                    }

                    if (is_array($value)) {
                        echo json_decode($value)." ";
                        continue;
                    }

                    echo e($name) . '="' . e($value) . '"'." ";
                }
            }, $attributes); ?>
               autocomplete="off"
               data-target="fields--datetime.instance"
        >

        <?php if(true === $allowEmpty): ?>
            <div class="input-group-append bg-white">
                <a class="input-group-text bg-transparent"
                   title="clear"
                   data-action="click->fields--datetime#clear">
                        <i class="icon-cross"></i>
                    </a>
                </div>
            <?php endif; ?>
        </div>
<?php if (isset($__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d)): ?>
<?php $component = $__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d; ?>
<?php unset($__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>




<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/fields/datetime.blade.php ENDPATH**/ ?>