<div class="row"
     data-controller="layouts--table"
     data-layouts--table-slug="<?php echo e($slug); ?>"
>
    <div class="w-100 table-responsive <?php if($striped): ?> table-striped <?php endif; ?>">
        <table class="table">
            <thead>
            <tr>
                <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $column->buildTh(); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            </thead>
            <tbody>

            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $column->buildTd($source); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php if($rows instanceof \Illuminate\Contracts\Pagination\Paginator && $rows->isEmpty()): ?>
            <div class="text-center bg-white pt-5 pb-5 w-100">
                <h3 class="font-thin">
                    <i class="<?php echo e($iconNotFound); ?> block m-b"></i>
                    <?php echo $textNotFound; ?>

                </h3>

                <?php echo $subNotFound; ?>

            </div>
        <?php endif; ?>

        <?php echo $__env->renderWhen($rows instanceof \Illuminate\Contracts\Pagination\Paginator && $rows->isNotEmpty(),
            'platform::layouts.pagination',[
                'paginator' => $rows,
                'columns' => $columns
            ]
          , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
    </div>



</div>

<?php /**PATH /home/dev/web/crm/vendor/orchid/platform/resources/views/layouts/table.blade.php ENDPATH**/ ?>