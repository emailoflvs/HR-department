<?php $__env->startSection('content'); ?>


    <?php if(isset($id)): ?>
        <form action="/hr_application_form_update/<?php echo e($id); ?>" method="POST" id="applicationForm" name="applicationForm"
              class="formWithValidation">
            <input name="applicationId" type="hidden" value="<?php echo e($id); ?>">
            <?php else: ?>
                <form action="/hr_application_form_store" method="POST" id="applicationForm" name="applicationForm">
                    <input type="hidden" name="_method" value="PUT">
                    <?php endif; ?>

                    <?php if(isset($personId)): ?>
                        <input name="personId" type="hidden" value="<?php echo e($personId); ?>">
                    <?php endif; ?>
                    <div class="analytics-container" align="center">

                        <div class="content center">
                            <div class="title m-b-md center">

                            </div>

                            <div class="page-content container-fluid" align="left">

                                <?php echo $__env->make('hr.application_form.html.application_form_html_div_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <table width="100%">
                                    <tr>
                                        <td><h3>Анкета кандидата в компанию
                                                <br>Холдинг "Симпатик Групп"</h3></td>
                                        <td><img src="/img/simpatik-logo.png" width="100"></td>
                                    </tr>
                                </table>

                                <p style="font-size: 19px">Уважаемый кандидат, Мы очень
                                    рады познакомиться с Вами! Для того, что наше с Вами знакомство было более
                                    продуктивным,
                                    предлагаем Вам заполнить анкету. Чтобы Вы ориентировались по времени, это займет 15
                                    минут. По любым вопросам, Вы можете обратиться к HR-менеджеру.
                                    <br>
                                </p>
                                <div class="freebirdFormviewerViewHeaderRequiredLegend"
                                     aria-hidden="true" dir="auto">
                                    <span style="color: red">
                                    *&nbsp;Обязательно
                                        </span>
                                </div>

                                <?php echo $__env->make('hr.application_form.html.application_form_html_div_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_input', ['question'=>
                                                                                        'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_select', ['question'=>
                                                                                        'filiation'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_input', ['question'=>
                                                                                        'years'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_input', ['question'=>
                                                                                        'phoneNumber'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_select', ['question'=>
                                                                                        'hrEmploymentRule'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_select', ['question'=>
                                                                                        'desiredSalaryFirst'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_select', ['question'=>
                                                                                        'desiredSalarySecond'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_select', ['question'=>
                                                                                        'infoSource'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                                <?php echo $__env->make('hr.application_form.html.application_form_html_input', ['question'=>
                                                                                        'infoSourceName',
                                                                                        'notRequired'=>1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                                <?php echo $__env->make('hr.application_form.html.application_form_html_input', ['question'=>'education',
                                                                                               'notRequired'=>1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_radio_checking', ['question'=>
                                                                                            'children'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_select', ['question'=>
                                                                                        'desiredWorkTime'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_select', ['question'=>
                                                                                        'hrWorkTerm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_select', ['question'=>
                                                                                        'function'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_radio_checking', ['question'=>
                                                                                           'operatorExperience'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_radio', ['question'=>
                                                                                                'opinion'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                                <?php echo $__env->make('hr.application_form.html.application_form_html_radio_horizontal2', ['question'=>
                                                                                                'workLocationRating'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




                                <?php echo $__env->make('hr.application_form.html.application_form_html_radio_horizontal', ['question'=>
                                                                                            'raisingCareerRating'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                                <?php echo $__env->make('hr.application_form.html.application_form_html_radio_horizontal2', ['question'=>
                                                                                                         'salaryImportant'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                                <?php echo $__env->make('hr.application_form.html.application_form_html_radio_horizontal', ['question'=>
                                                                                'professionalPersonalDevelopment'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                                <?php echo $__env->make('hr.application_form.html.application_form_html_radio_horizontal2', ['question'=>
                                                                                                 'prestigeWork'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_textarea', ['question'=>
                                                                                                 'ruToUaTranslation'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_select', ['question'=>
                                                                                        'computerSkills'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_select', ['question'=>
                                                                              'computerSkillsTurnOff'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_select', ['question'=>
                                                                              'computerSkillsPusk'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_textarea', ['question'=>
                                                                                                 'uaToRuTranslation'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_checkbox', ['question'=>
                                                                              'hrPersonDocuments'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                <?php echo $__env->make('hr.application_form.html.application_form_html_checkbox', ['question'=>
                                                                              'hrCompTechnicalRequirements'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




                                <?php echo $__env->make('hr.application_form.html.application_form_html_div_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <input type="submit" value="Отправить" class="btn btn-primary pull-right"
                                       onclick="validateForm()">
                                <?php echo $__env->make('hr.application_form.html.application_form_html_div_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                    </div>
                    <?php echo e(csrf_field()); ?>)
                </form>

                <script>
                    function validateRadio(element) {
                        var check = "";
                        var inp = document.getElementsByName(element);
                        for (var i = 0; i < inp.length; i++) {
                            if (inp[i].type == "radio" && inp[i].checked)
                                check = inp[i].value;
                        }
                        if (!check)
                            $('#' + element).show();
                        else
                            $('#' + element).hide();
                    }

                    function validateForm() {

                        var elements = [];

                        //собираем в массив все элементы формы типа radio
                        $("form[name='applicationForm']").find("input").not('[type="submit"]').each(function () {
                            if ($(this).attr('type') == 'radio')
                                elements.push($(this).attr('name'));
                        });

                        //удаляю дубликаты
                        let inputRadioNames = [...new Set(elements)]

                        //проверяю валидацию
                        for (var i = 0; i < inputRadioNames.length; i++) {
                            validateRadio(inputRadioNames[i]);
                        }
                        return true;
                    };

                </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_form_single', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/servers/simpatik/resources/views/hr/application_form/application_form_edit.blade.php ENDPATH**/ ?>
