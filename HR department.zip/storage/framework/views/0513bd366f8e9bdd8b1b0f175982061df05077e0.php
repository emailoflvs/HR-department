<div class="toast-wrapper" data-controller="layouts--toast">
    <template id="toast">
        <div class="toast"
             role="alert"
             aria-live="assertive"
             aria-atomic="true"
             data-delay="5000"
             data-autohide="true">
            <div class="toast-body p-3 bg-light">
                <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <p class="mb-0"> <i class="icon-circle text-{type} mr-2"></i> {message}</p>
            </div>
        </div>
    </template>


    <?php if(session()->has(\Orchid\Alert\Toast::SESSION_MESSAGE)): ?>
        <div class="toast" role="alert" aria-live="assertive" aria-atomic="true" data-delay="<?php echo e(session(\Orchid\Alert\Toast::SESSION_DELAY)); ?>"
             data-autohide="<?php echo e(session(\Orchid\Alert\Toast::SESSION_AUTO_HIDE)); ?>">
            <div class="toast-body p-3 bg-light">
                <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <p class="mb-0">
                    <i class="icon-circle text-<?php echo e(session(\Orchid\Alert\Toast::SESSION_LEVEL)); ?> mr-2"></i>
                    <?php echo e(session(\Orchid\Alert\Toast::SESSION_MESSAGE)); ?>

                </p>
            </div>
        </div>
    <?php endif; ?>

</div>


<?php /**PATH /home/dev/web/crm/vendor/orchid/platform/resources/views/partials/toast.blade.php ENDPATH**/ ?>