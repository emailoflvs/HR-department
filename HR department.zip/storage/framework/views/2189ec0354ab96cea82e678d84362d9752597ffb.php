<?php echo $__env->make('hr.application_form.html.application_form_html_div_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h5>
    <?php echo e($questions[$question]['question'] ?? ''); ?>

    <span style="color: red">*</span></h5>
<?php if(isset($questions[$question]['answers'])): ?>
    <?php $__currentLoopData = $questions[$question]['answers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>
            <label class="checkbox-other">
                <input type="checkbox" name="checkbox-<?php echo e($question); ?>-<?php echo e($answer['id']); ?>" value="<?php echo e($answer['id']); ?>">
                <?php echo e($answer['answer']); ?>

            </label>
        </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php echo $__env->make('hr.application_form.html.application_form_html_div_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/servers/simpatik/resources/views/hr/application_form/html/application_form_html_checkbox.blade.php ENDPATH**/ ?>