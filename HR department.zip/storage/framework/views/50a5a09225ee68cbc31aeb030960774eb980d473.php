<?php $__env->startSection('content'); ?>


    <?php if(isset($id)): ?>
        <form action="/application_form_update/<?php echo e($id); ?>" method="POST" id="applicationForm"
              name="applicationForm" class="formWithValidation">
            <input name="applicationId" type="hidden" value="<?php echo e($id); ?>">
            <?php else: ?>
                <form action="/application_form_store" method="POST" id="applicationForm"
                      name="applicationForm">
                    <input type="hidden" name="_method" value="PUT">
                    <?php endif; ?>


                    
                    <h1 class="page-title">
                        <i class="voyager-question"></i> Список вопросов в анкете
                        "<?php echo e($applicationForm['name'] ?? ''); ?>

                        "
                    </h1>
                    <div id="voyager-notifications"></div>

                    <div class="page-content container-fluid">
                        <div class="row">
                            <div id="dbManager" class="col-md-12">

                                <table class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th width="40%">Вопрос</th>
                                        
                                        <th width="80%">Потенциальные ответы</th>
                                        <th width="10%">Комментарии</th>
                                        <th width="1%">Статус</th>
                                        
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php if(isset($questions)): ?>
                                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($question['question'] ?? ''); ?></td>
                                                <td><?php if(isset($question['answers'])): ?>
                                                        <?php $__currentLoopData = $question['answers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php echo e($answer['answer'] ?? ''); ?><br>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/servers/simpatik/resources/views/hr/application_form/application_form_edit.blade.php ENDPATH**/ ?>