<table class="table table-bordered">
    <thead>
    <tr>
        <th>Источник</th>
        <th width="15%">Отклик по рассылке</th>
        <th>Мессенджер</th>
        <th>HR менеджер</th>
    </tr>
    </thead>
    <tbody>
    <tr class="newTableRow">
        <td width="20%">
            <select name="hrInfoSource" id="hrInfoSource" class="form-control">
                <option value="">
                </option>
                <?php if(isset($hrInfoSources)): ?>
                    <?php $__currentLoopData = $hrInfoSources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hrInfoSource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($hrInfoSource->id); ?>">
                            <?php echo e($hrInfoSource->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
            <script>
                $('#hrInfoSource option[value=<?php echo e($person->hrInfoSource ?? '0'); ?>]').prop('selected', true);
            </script>
        </td>

        <td>
            <input type="checkbox" name="mailResponse" id="mailResponse">

            <span onclick='checkMailResponse()'>Отклик по рассылке</span>

            
            <select name="mailResponseFiliation" id="mailResponseFiliation"
                    class="form-control" style="display: none;">
                <option value="0">город
                </option>
                <?php if(isset($filiations)): ?>
                    <?php $__currentLoopData = $filiations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filiation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($filiation->id); ?>">
                            <?php echo e($filiation->cityName); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>

            
            <script language="JavaScript">
                <!--
                function checkMailResponse() {
                    var id = "#mailResponse";
                    if ($(id).is(':checked', true)) {
                        // Снять checkbox
                        $(id).prop('checked', false);
                        //спрятать список городов
                        $('#mailResponseFiliation').hide();
                        $('#mailResponseFiliation option[value=<?php echo e($person->mailResponseFiliation ?? '0'); ?>]').prop('selected', false);

                    } else {
                        // Отметить checkbox
                        $(id).prop('checked', true);
                        //показать список городов
                        $('#mailResponseFiliation').show();
                    }
                }

                -->
            </script>
            <?php if(empty($person->mailResponseFiliation)): ?>
            <?php else: ?>
                <script>
                    // Отметить checkbox
                    $("#mailResponse").prop('checked', true);
                    //показать список городов
                    $('#mailResponseFiliation').show();

                    $('#mailResponseFiliation option[value=<?php echo e($person->mailResponseFiliation ?? '0'); ?>]').prop('selected', true);
                </script>
            <?php endif; ?>

        </td>
        <td>
            <select name="messenger" id="messenger" class="form-control">
                <option value="">
                    -
                </option>
                <?php if(isset($messengers)): ?>
                    <?php $__currentLoopData = $messengers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $messenger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($messenger->id); ?>">
                            <?php echo e($messenger->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
            <script>
                $('#messenger option[value=<?php echo e($person->messenger ?? '0'); ?>]').prop('selected', true);
            </script>
        </td>
        <td>
            <select name="hrOperator" id="hrOperator" class="form-control">
                <option value="">
                    -
                </option>
                <?php if(isset($hrOperators)): ?>
                    <?php $__currentLoopData = $hrOperators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hrOperator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($hrOperator->id); ?>">
                            <?php echo e($hrOperator->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
            <script>
                $('#hrOperator option[value=<?php echo e($person->hrOperator ?? ''); ?>]').prop('selected', true);
            </script>
        </td>
    </tr>
    </tbody>
</table>
<?php /**PATH /home/servers/simpatik/resources/views/hr/application_form/application_form_buttom.blade.php ENDPATH**/ ?>