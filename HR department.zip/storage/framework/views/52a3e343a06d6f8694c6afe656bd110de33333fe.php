<div class="modal relationship fade" tabindex="-1" id="call_place_exit_modal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">


                    <button type="button" class="close" data-dismiss="modal" aria-label="Закрыть"><span
                            aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">
                        <i class="voyager-plus"></i>
                        Вы действительно хотите выйти?
                    </h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <form name="working" action="/working" method="POST">
                        
                        <input type="hidden" name="working_status" value="0">
                        <?php echo e(csrf_field()); ?>


                        <h5 class="modal-title">Причина выхода:</h5>

                    <select name="out-reason" class="form-control input-sm" id="out-reason">
                        <?php
                            use App\WorkingStatus;
                            foreach (WorkingStatus::where ('type','=',0)->get() as $item)
                                echo "<option value='".$item->getAttributes()['id']."'>".$item->getAttributes()['name']."</option>";
                        ?>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <input type="submit" class="btn btn-success pull-right"
                       value="Выйти">
                
                
                
                
                
                

                <button type="button" class="btn btn-default pull-right" data-dismiss="modal">
                    Отмена
                </button>
                </form>
            </div>
            
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->







































<?php /**PATH /home/servers/simpatik/resources/views/modals/call_place_exit.blade.php ENDPATH**/ ?>