
<div id="noContactDiv<?php echo e($action['id'] ?? ''); ?>" style="display: none;">
    <div class="col-md-12 form-group">
        Время повторного звонка:<br>
        
        
        

        
        
        
        
        
        
        
        
        
        
        

        <input id="interviewReason<?php echo e($action['id'] ?? '0'); ?>"
               name="interviewReason_<?php echo e($action['id'] ?? '0'); ?>"
               type="hidden" value="">

        <input id="planActionDate<?php echo e($action['id'] ?? ''); ?>" type="date"
               name="planActionDate_<?php echo e($action['id'] ?? '0'); ?>"
               value="<?php echo e($action['planActionDate'] ?? date("yy-m-d")); ?>">

        <select id="planActionTime<?php echo e($action['id'] ?? ''); ?>"
                name="planActionTime_<?php echo e($action['id'] ?? '0'); ?>">
            <option></option>
            <option value="09:00">09:00</option>
            <option value="09:30">09:30</option>
            <?php for($i = 10; $i < 19; $i++): ?>
                <option value="<?php echo e($i); ?>:00"><?php echo e($i); ?>:00</option>
                <option value="<?php echo e($i); ?>:30"><?php echo e($i); ?>:30</option>
            <?php endfor; ?>
        </select>
        <script>
            $('#planActionTime<?php echo e($action['id'] ?? ''); ?> option[value="<?php echo e($action['planActionTime'] ?? ''); ?>"]')
                .prop('selected', true);
        </script>
        <br>Отправьте шаблон сообщения в мессенджер.
    </div>
</div>



<div id="inviteDiv<?php echo e($action['id'] ?? ''); ?>" style="display: none;">
    <div class="col-md-12 form-group">
        <select name="actionResult_<?php echo e($action['id'] ?? ''); ?>" id="actionResult<?php echo e($action['id'] ?? ''); ?>"
                class="form-control">
            <option></option>
            <option value="clarification">На уточнении</option>
            <option value="invite">Приглашен на собеседованиие</option>
            <option value="refusing">Отказ</option>
        </select>

        <script>
            $('#actionResult<?php echo e($action['id'] ?? ''); ?> option[value="<?php echo e($interview->actionResult ?? ''); ?>"]')
                .prop('selected', true);
        </script>

        
        <div id="clarification<?php echo e($action['id'] ?? ''); ?>"
             style="display: none;"
        ><br>
            Время следующего звонка:<br>
            <input id="planInviteClarificationRecallDate<?php echo e($interview['id'] ?? ''); ?>" type="date"
                   name="planInviteClarificationRecallDate_<?php echo e($interview['id'] ?? '0'); ?>"
                   value="<?php echo e($interview->planInviteClarificationRecallDate ?? date("yy-m-d")); ?>">

            <select id="planInviteClarificationRecallTime<?php echo e($interview['id'] ?? ''); ?>"
                    name="planInviteClarificationRecallTime_<?php echo e($interview['id'] ?? '0'); ?>">
                <option></option>
                <option value="09:00">09:00</option>
                <option value="09:30">09:30</option>
                <?php for($i = 10; $i < 19; $i++): ?>
                    <option value="<?php echo e($i); ?>:00"><?php echo e($i); ?>:00</option>
                    <option value="<?php echo e($i); ?>:30"><?php echo e($i); ?>:30</option>
                <?php endfor; ?>
            </select>
            <script>
                $('#planInviteClarificationRecallTime<?php echo e($interview['id'] ?? ''); ?> option[value="<?php echo e($interview->planInviteClarificationRecallTime ?? '0'); ?>"]').prop('selected', true);
            </script>
            <br>
            <input type="text" id="inviteClarificationDetails<?php echo e($interview['id'] ?? ''); ?>"
                   name="inviteClarificationDetails_<?php echo e($interview['id'] ?? '0'); ?>"
                   placeholder="В чем причина уточнения?"
                   class="form-control"
                   value="<?php echo e($interview->inviteClarificationDetails ?? ''); ?>"
            >
        </div>

        

        
        
        
        
        
        
        
        

        
        <div id="inviteInterview<?php echo e($action['id'] ?? ''); ?>"
             style="display: none;"
        >
            <br> Время собеседования:
            
            

            <br><input id="planInterviewDate<?php echo e($interview['id'] ?? ''); ?>" type="date"
                       name="planInterviewDate_<?php echo e($interview['id'] ?? '0'); ?>"
                       value="<?php echo e($interview->planInterviewDate ?? ''); ?>">
            <select id="planInterviewTime<?php echo e($action['id'] ?? ''); ?>"
                    name="planInterviewTime_<?php echo e($action['id'] ?? ''); ?>">
                <option></option>
                <option value="09:00">09:00</option>
                <option value="09:30">09:30</option>
                <?php for($i = 10; $i < 19; $i++): ?>
                    <option value="<?php echo e($i); ?>:00"><?php echo e($i); ?>:00</option>
                    <option value="<?php echo e($i); ?>:30"><?php echo e($i); ?>:30</option>
                <?php endfor; ?>
            </select>
            <script>
                $('#planInterviewTime option[value="<?php echo e($interview->planInterviewTime ?? ''); ?>"]').prop('selected', true);
            </script>
            <br>
            <br>График работы:
            <select name="timetable_<?php echo e($action['id'] ?? ''); ?>" id="timetable<?php echo e($action['id'] ?? ''); ?>"
                    class="form-control" width="10px">
                <option value="">
                    -
                </option>
                <?php if(isset($timetables)): ?>
                    <?php $__currentLoopData = $timetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timetable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($timetable->id); ?>">
                            <?php echo e($timetable->timetable); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
            <script>
                $('#timetable<?php echo e($action['id'] ?? ''); ?> option[value=<?php echo e($interview->timetable ?? ''); ?>]').prop('selected', true);
            </script>

            <br>Направление работы:
            <select name="hrSpecialization_<?php echo e($action['id'] ?? ''); ?>"
                    id="hrSpecialization<?php echo e($action['id'] ?? ''); ?>" class="form-control"
                    width="10px">
                <option value="">
                    -
                </option>
                <?php if(isset($hrSpecializations)): ?>
                    <?php $__currentLoopData = $hrSpecializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hrSpecialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($hrSpecialization->id); ?>">
                            <?php echo e($hrSpecialization->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
            <script>
                $('#hrSpecialization<?php echo e($action['id'] ?? ''); ?> option[value=<?php echo e($interview->hrSpecialization ?? ''); ?>]').prop('selected', true);
            </script>
            <br>

        </div>


        
        <div id="refusing<?php echo e($action['id'] ?? ''); ?>"
             style="display: none;"
        >
            <br>
            Причина отказа со стороны компании:
            <select name="inviteRefusingReasonCompany_<?php echo e($action['id'] ?? ''); ?>"
                    id="inviteRefusingReasonCompany<?php echo e($action['id'] ?? ''); ?>"
                    class="form-control" width="10px">
                <option value="">
                    -
                </option>
                <?php if(isset($inviteRefusingReasonsCompany)): ?>
                    <?php $__currentLoopData = $inviteRefusingReasonsCompany; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inviteRefusingReason): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($inviteRefusingReason->id); ?>">
                            <?php echo e($inviteRefusingReason->reason); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <option value="0">
                    Другое
                </option>
            </select>
            <script>
                $('#inviteRefusingReasonCompany<?php echo e($action['id'] ?? ''); ?> option[value=<?php echo e($interview->inviteRefusingReasonCompany ?? ''); ?>]').prop('selected', true);
            </script>

            <input type="text" id="inviteRefusingReasonCompanyDetails<?php echo e($action['id'] ?? ''); ?>"
                   name="inviteRefusingReasonCompanyDetails_<?php echo e($action['id'] ?? ''); ?>"
                   placeholder="причина отказа"
                   style="display: none;"
                   class="form-control"
                   value="<?php echo e($interview->inviteRefusingReasonCompanyDetails ?? ''); ?>">

            <script>
                $('#inviteRefusingReasonCompany' +<?php echo e($action['id'] ?? ''); ?>).change(function () {
                    var el = $(this);
                    if (el.val() === "0") {
                        $('#inviteRefusingReasonCompanyDetails' +<?php echo e($action['id'] ?? ''); ?>).show();
                    } else {
                        $('#inviteRefusingReasonCompanyDetails' +<?php echo e($action['id'] ?? ''); ?>).hide();
                    }
                });
                if ($('#inviteRefusingReasonCompanyDetails' +<?php echo e($action['id'] ?? ''); ?>).val()) {
                    $('#inviteRefusingReasonCompany<?php echo e($action['id'] ?? ''); ?> option[value=0]').prop('selected', true);
                    $('#inviteRefusingReasonCompanyDetails' +<?php echo e($action['id'] ?? ''); ?>).show();
                }
            </script>
            <br>
            Причина отказа со стороны кандидата:
            <select name="inviteRefusingReasonPerson_<?php echo e($action['id'] ?? ''); ?>"
                    id="inviteRefusingReasonPerson<?php echo e($action['id'] ?? ''); ?>"
                    class="form-control" width="10px">
                <option value="">
                    -
                </option>
                <?php if(isset($inviteRefusingReasonsPerson)): ?>
                    <?php $__currentLoopData = $inviteRefusingReasonsPerson; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inviteRefusingReason): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($inviteRefusingReason->id); ?>">
                            <?php echo e($inviteRefusingReason->reason); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <option value="0">
                    Другое
                </option>
            </select>
            <script>
                $('#inviteRefusingReasonPerson<?php echo e($action['id'] ?? ''); ?> option[value=<?php echo e($interview->inviteRefusingReasonPerson ?? ''); ?>]').prop('selected', true);
            </script>

            <input type="text" id="inviteRefusingReasonPersonDetails<?php echo e($action['id'] ?? ''); ?>"
                   name="inviteRefusingReasonPersonDetails_<?php echo e($action['id'] ?? ''); ?>"
                   placeholder="причина отказа"
                   style="display: none;"
                   class="form-control"
                   value="<?php echo e($interview->inviteRefusingReasonPersonDetails ?? ''); ?>"
            >
            <script>
                $('#inviteRefusingReasonPerson' +<?php echo e($action['id'] ?? ''); ?>).change(function () {
                    var el = $(this);
                    if (el.val() === "0") {
                        $('#inviteRefusingReasonPersonDetails' +<?php echo e($action['id'] ?? ''); ?>).show();
                    } else {
                        $('#inviteRefusingReasonPersonDetails' +<?php echo e($action['id'] ?? ''); ?>).hide();
                    }
                });
                if ($('#inviteRefusingReasonPersonDetails' +<?php echo e($action['id'] ?? ''); ?>).val()) {
                    $('#inviteRefusingReasonPerson<?php echo e($action['id'] ?? ''); ?> option[value=0]').prop('selected', true);
                    $('#inviteRefusingReasonPersonDetails' +<?php echo e($action['id'] ?? ''); ?>).show();
                }
            </script>
        </div>
    </div>
</div>

<script language="JavaScript">
    <!--
    
        
        
        
        

    if (('<?php echo e($interview->actionResult ?? ''); ?>' +<?php echo e($action['id'] ?? ''); ?>) === 'invite') {
        $('#inviteInterview' +<?php echo e($action['id'] ?? ''); ?>).show();
        $('#refusing' +<?php echo e($action['id'] ?? ''); ?>).hide();
        $('#clarification' +<?php echo e($action['id'] ?? ''); ?>).hide();
    }

    if (('<?php echo e($interview->actionResult ?? ''); ?>' +<?php echo e($action['id'] ?? ''); ?>) === 'refusing') {
        // $("#inviteCheckbox").prop('checked', true);
        $('#inviteInterview' +<?php echo e($action['id'] ?? ''); ?>).hide();
        $('#clarification' +<?php echo e($action['id'] ?? ''); ?>).hide();
        $('#refusing' +<?php echo e($action['id'] ?? ''); ?>).show();
    }

    if (('<?php echo e($interview->actionResult ?? ''); ?>' +<?php echo e($action['id'] ?? ''); ?>) === 'clarification') {
        $("#refusing" +<?php echo e($action['id'] ?? ''); ?>).hide();
        $('#inviteInterview' +<?php echo e($action['id'] ?? ''); ?>).hide();
        $('#clarification' +<?php echo e($action['id'] ?? ''); ?>).show();
    }

    $('#actionResult' +<?php echo e($action['id'] ?? ''); ?>).change(function () {
        if ($("#actionResult" +<?php echo e($action['id'] ?? ''); ?>).prop('selected', true)) {
            var el = $('#actionResult' +<?php echo e($action['id'] ?? ''); ?>);
            if (el.val() === "invite") {
                $('#inviteInterview' +<?php echo e($action['id'] ?? ''); ?>).show();
                $('#clarification' +<?php echo e($action['id'] ?? ''); ?>).hide();
                $('#refusing' +<?php echo e($action['id'] ?? ''); ?>).hide();

            } else if (el.val() === "clarification") {
                $('#inviteInterview' +<?php echo e($action['id'] ?? ''); ?>).hide();
                $('#refusing' +<?php echo e($action['id'] ?? ''); ?>).hide();
                $('#clarification' +<?php echo e($action['id'] ?? ''); ?>).show();
            } else if (el.val() === "refusing") {
                $('#inviteInterview' +<?php echo e($action['id'] ?? ''); ?>).hide();
                $('#refusing' +<?php echo e($action['id'] ?? ''); ?>).show();
                $('#clarification' +<?php echo e($action['id'] ?? ''); ?>).hide();
            }
        }
    });

    // $('#hrActionContactResult').show();

    function inviteInterview() {
        var id = "#inviteCheckbox" +<?php echo e($action['id'] ?? ''); ?>;
        if ($(id).is(':checked', true)) {
            // Снять checkbox
            // $(id).prop('checked', false);
            //спрятать список городов
            $('#inviteInterview' +<?php echo e($action['id'] ?? ''); ?>).show();
            $('#noInviteInterview' +<?php echo e($action['id'] ?? ''); ?>).hide();

        } else {
            // // Отметить checkbox
            // $(id).prop('checked', true);
            //показать время собеседования
            $('#inviteInterview' +<?php echo e($action['id'] ?? ''); ?>).hide();
            $('#noInviteInterview' +<?php echo e($action['id'] ?? ''); ?>).show();
        }
    }

    -->
</script>

<?php /**PATH /home/servers/simpatik/resources/views/hr/person_info_form_action_result.blade.php ENDPATH**/ ?>