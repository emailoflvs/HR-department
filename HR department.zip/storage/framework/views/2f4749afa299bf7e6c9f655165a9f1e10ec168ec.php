<?php $__env->startComponent($typeForm, get_defined_vars()); ?>
    <div data-controller="fields--cropper"
         data-fields--cropper-value="<?php echo e($attributes['value']); ?>"
         data-fields--cropper-storage="<?php echo e($storage ?? 'public'); ?>"
         data-fields--cropper-width="<?php echo e($width); ?>"
         data-fields--cropper-height="<?php echo e($height); ?>"
         data-fields--cropper-min-width="<?php echo e($minWidth); ?>"
         data-fields--cropper-min-height="<?php echo e($minHeight); ?>"
         data-fields--cropper-max-width="<?php echo e($maxWidth); ?>"
         data-fields--cropper-max-height="<?php echo e($maxHeight); ?>"
         data-fields--cropper-target="<?php echo e($target); ?>"
         data-fields--cropper-url="<?php echo e($url); ?>"
         data-fields--cropper-max-file-size="<?php echo e($maxFileSize); ?>"
    >
        <div class="border-dashed text-right p-3 cropper-actions">

            <div class="fields-cropper-container">
                <img src="#" class="cropper-preview img-fluid img-full m-b-md border" alt="">
            </div>

            <span class="mt-1 float-left"><?php echo e(__('Upload image from your computer:')); ?></span>

            <div class="btn-group">
                <label class="btn btn-default m-n">
                    <i class="icon-cloud-upload mr-2"></i> <?php echo e(__('Browse')); ?>

                    <input type="file"
                           accept="image/*"
                           data-target="fields--cropper.upload"
                           data-action="change->fields--cropper#upload click->fields--cropper#openModal"
                           class="d-none">
                </label>

                <button type="button" class="btn btn-outline-danger cropper-remove"
                        data-action="fields--cropper#clear"><?php echo e(__('Remove')); ?></button>
            </div>

            <input type="file"
                   accept="image/*"
                   class="d-none">
        </div>

        <input class="cropper-path d-none"
               type="text"
               data-target="fields--cropper.source"
            <?php call_user_func(function ($attributes) {
                foreach ($attributes as $name => $value) {
                    if (is_null($value)) {
                        continue;
                    }

                    if (is_bool($value) && $value === false) {
                        continue;
                    }
                    if (is_bool($value)) {
                        echo e($name)." ";
                        continue;
                    }

                    if (is_array($value)) {
                        echo json_decode($value)." ";
                        continue;
                    }

                    echo e($name) . '="' . e($value) . '"'." ";
                }
            }, $attributes); ?>
        >

        <div class="modal" role="dialog">
            <div class="modal-dialog modal-lg">
                <div class="modal-content-wrapper">
                    <div class="modal-content">
                        <div class="position-relative">
                            <img class="upload-panel">
                        </div>

                        <div class="modal-footer">

                            <button type="button"
                                    class="btn btn-link"
                                    data-dismiss="modal">
                                <?php echo e(__('Close')); ?>

                            </button>

                            <button type="button"
                                    class="btn btn-default"
                                    data-action="fields--cropper#crop">
                                <?php echo e(__('Crop')); ?>

                            </button>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php if (isset($__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d)): ?>
<?php $component = $__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d; ?>
<?php unset($__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/fields/cropper.blade.php ENDPATH**/ ?>