<?php if(isset($id)): ?>
    <form action="/hr_application_form_update/<?php echo e($id); ?>" method="POST">
        <input name="applicationId" type="hidden" value="<?php echo e($id); ?>">
        
        
        
        <?php else: ?>
            <form action="/hr_application_form_store" method="POST">
                <input type="hidden" name="_method" value="PUT">
                <?php endif; ?>

                
                
                <?php if(isset($personId)): ?>
                    <input name="personId" type="hidden" value="<?php echo e($personId); ?>">
                <?php endif; ?>
                <?php if(isset($questions)): ?>

                    <h5>
                        <?php echo e($questions['filiations']['question'] ?? ''); ?>

                    </h5>
                    <select name="personFiliation" id="personFiliation"
                            class="form-control">
                        <option value="">
                        </option>
                        <?php if(isset($filiations)): ?>
                            <?php $__currentLoopData = $filiations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filiation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($filiation->id); ?>">
                                    <?php echo e($filiation->cityName); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>

                    <script>
                        $('#personFiliation option[value=<?php echo e($person->personFiliation ?? '0'); ?>]').prop('selected', true);
                    </script>

                    <h5>
                        <?php echo e($questions['name']['question'] ?? ''); ?>

                    </h5>
                    <input type="text" name="name"
                           class="form-control" placeholder="" value="">

                    <h5>
                        <?php echo e($questions['phoneNumber']['question'] ?? ''); ?>

                    </h5>
                    <input type="text" name="phoneNumber"
                           class="form-control" placeholder="" value="">

                    <h5>
                        <?php echo e($questions['years']['question'] ?? ''); ?>

                    </h5>
                    <input type="text" name="phoneNumber"
                           class="form-control" placeholder="" value="">



                    <h5>
                        <?php echo e($questions['hrEmploymentRules']['question'] ?? ''); ?>

                    </h5>
                    <select name="hrEmploymentRules" id="hrEmploymentRules">
                        <option></option>
                        <?php $__currentLoopData = $questions['hrEmploymentRules']['answers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($answer['id'] ?? ''); ?>"><?php echo e($answer['answer'] ?? ''); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <h5>
                        <?php echo e($questions['desiredSalaryFirst']['question'] ?? ''); ?>

                    </h5>
                    <select name="desiredSalaryFirst" id="desiredSalaryFirst">
                        <option></option>
                        <?php $__currentLoopData = $questions['desiredSalaryFirst']['answers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($answer['id'] ?? ''); ?>"><?php echo e($answer['answer'] ?? ''); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <h5>
                        <?php echo e($questions['desiredSalarySecond']['question'] ?? ''); ?>

                    </h5>
                    <select name="desiredSalarySecond" id="desiredSalarySecond">
                        <option></option>
                        <?php $__currentLoopData = $questions['desiredSalarySecond']['answers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($answer['id'] ?? ''); ?>"><?php echo e($answer['answer'] ?? ''); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <h5>
                        <?php echo e($questions['infoSources']['question'] ?? ''); ?>

                    </h5>
                    <select name="infoSource" id="infoSource" class="form-control">
                        <option value="">
                        </option>
                        <?php if(isset($infoSources)): ?>
                            <?php $__currentLoopData = $infoSources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infoSource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($infoSource->id); ?>">
                                    <?php echo e($infoSource->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                    <script>
                        $('#infoSources option[value=<?php echo e($person->hrInfoSource ?? '0'); ?>]').prop('selected', true);
                    </script>

                    <h5>
                        <?php echo e($questions['computerSkillsTurnOff']['question'] ?? ''); ?>

                    </h5>
                    <select name="computerSkillsTurnOff" id="computerSkillsTurnOff">
                        <option></option>
                        <?php $__currentLoopData = $questions['computerSkillsTurnOff']['answers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($answer['id'] ?? ''); ?>"><?php echo e($answer['answer'] ?? ''); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>



                <?php endif; ?>
                <div id="alertsContainer"></div>
                


                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th width="10%">Дата</th>
                        <th>Фамилия</th>
                        <th>Имя</th>
                        <th>Номер телефона</th>
                        <th>Город</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr class="newTableRow">
                        <td>
                            <input type="date" min="1990-01-01" name="dateAddedToDatabase" class="form-control"
                                   value="<?php echo e($person->dateAddedToDatabase ?? date("Y-m-d")); ?>">
                        </td>
                        <td>
                            <input type="text" name="surname"
                                   class="form-control" placeholder="Фамилия" value="<?php echo e($person->surname ?? ''); ?>">
                        </td>
                        <td>
                            
                            
                        </td>
                        <td>
                            
                            
                            
                        </td>
                        <td>

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                        </td>
                    </tr>
                    </tbody>
                </table>
<?php /**PATH /home/servers/simpatik/resources/views//hr/application_form/application_form_top.blade.php ENDPATH**/ ?>