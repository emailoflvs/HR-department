<?php if(isset($interviews)): ?>
    Результаты созвона:
    <table class="table table-bordered" style="width: 100%;">
        <thead>
        <tr>

            <th width="10%">Планируется:</th>
            <th width="10%">Проведено:</th>
            <th width="10%">Причина</th>
            <th width="50%">Статус:</th>
            <th width="30%">Комментарий</th>

        </tr>
        </thead>
        <tbody>

        <?php $__currentLoopData = $interviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if(isset($interview['id'])): ?>
                <input name="interviewId_<?php echo e($interview['id'] ?? ''); ?>" type="hidden"
                       value="<?php echo e($interview['id'] ?? ''); ?>">
                
                
            <?php endif; ?>

            <tr class="newTableRow">
                <td style="white-space: nowrap;">
                    <?php echo e($interview['planInterviewDate'] ?? ''); ?>  <?php echo e($interview['planInterviewTime'] ?? ''); ?>

                    
                    
                    
                    

                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                </td>
                <td style="white-space: nowrap;">
                    <?php echo e($interview['happenInterviewDate'] ?? ''); ?>  <?php echo e($interview['happenInterviewTime'] ?? ''); ?>

                    
                    
                    
                    

                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                </td>
                <td>
                    <?php echo e($interview['reason']??''); ?>

                </td>
                <td>

                    <?php if(isset($interview['inviteResult'])): ?>
                        <?php if($interview['inviteResult'] == 'invite'): ?>
                            <span class="btn btn-success" style="cursor:text;">Приглашен на собеседование</span>

                            <?php if(isset($interview['timetable'])): ?>
                                <br>График работы:
                                
                                
                                
                                
                                
                                
                                
                                <?php if(isset($timetables)): ?>
                                    <?php $__currentLoopData = $timetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timetable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($interview['timetable'] == $timetable->id): ?>
                                            
                                            <?php echo e($timetable->timetable); ?>

                                            
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                                
                                
                                
                                
                            <?php endif; ?>

                            <?php if(isset($interview['hrSpecialization'])): ?>
                                <br>Направление работы:
                                
                                
                                
                                
                                
                                
                                <?php if(isset($hrSpecializations)): ?>
                                    <?php $__currentLoopData = $hrSpecializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hrSpecialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        
                                        
                                        <?php if($interview['hrSpecialization'] == $hrSpecialization->id): ?>
                                            
                                            <?php echo e($hrSpecialization->name); ?>

                                            
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                                
                                
                                
                                
                            <?php endif; ?>
                        <?php endif; ?>


                        <?php if($interview['inviteResult'] == 'clarification'): ?>

                            <span class="btn btn-warning" style="cursor:text;">На уточнении</span>


                            <?php if(isset($interview['inviteClarification']->reason)): ?>
                                <br>Причина: <?php echo e($interview['inviteClarification']->reason); ?>

                            <?php endif; ?>
                            <?php if(isset($interview['inviteClarificationDetails'])): ?>
                                <br>Подробнее: <?php echo e($interview['inviteClarificationDetails']); ?>

                            <?php endif; ?>

                            <?php if(isset($interview['planInviteClarificationRecallDate'])): ?>
                                <br>Перезвонить:
                                <input id="planInviteClarificationRecallDate<?php echo e($interview['id'] ?? ''); ?>" type="date"
                                       name="planInviteClarificationRecallDate_<?php echo e($interview['id'] ?? ''); ?>"
                                       value="<?php echo e($interview['planInviteClarificationRecallDate'] ?? date("yy-m-d")); ?>">

                                <select id="planInviteClarificationRecallTime<?php echo e($interview['id'] ?? ''); ?>"
                                        name="planInviteClarificationRecallTime_<?php echo e($interview['id'] ?? ''); ?>">
                                    <option></option>
                                    <option value="09:00">09:00</option>
                                    <option value="09:30">09:30</option>
                                    <?php for($i = 10; $i < 19; $i++): ?>
                                        <option value="<?php echo e($i); ?>:00"><?php echo e($i); ?>:00</option>
                                        <option value="<?php echo e($i); ?>:30"><?php echo e($i); ?>:30</option>
                                    <?php endfor; ?>
                                </select>
                                <script>
                                    $('#planInviteClarificationRecallTime<?php echo e($interview['id'] ?? ''); ?> option[value="<?php echo e($interview['planInviteClarificationRecallTime'] ?? ''); ?>"]')
                                        .prop('selected', true);
                                </script>
                            <?php endif; ?>
                        <?php endif; ?>

                        <?php if($interview['inviteResult'] == 'refusing'): ?>
                            <span class="btn btn-danger" style="cursor:text;">Отказ</span>

                            <?php if(isset($interview['inviteRefusingReasonCompany'])): ?>
                                <br>Со стороны компании: <?php echo e($interview['inviteRefusingReasonCompany']); ?>

                            <?php endif; ?>
                            <?php if(isset($interview['inviteRefusingReasonCompanyDetails'])): ?>
                                <br>Со стороны
                                компании: <?php echo e($interview['inviteRefusingReasonCompanyDetails']); ?>

                            <?php endif; ?>

                            <?php if(isset($interview['inviteRefusingReasonPerson'])): ?>
                                <br>Со стороны компании: <?php echo e($interview['inviteRefusingReasonPerson']); ?>

                            <?php endif; ?>
                            <?php if(isset($interview['inviteRefusingReasonPersonDetails'])): ?>
                                <br>Со стороны
                                кандидата: <?php echo e($interview['inviteRefusingReasonPersonDetails']); ?>

                            <?php endif; ?>
                            
                        <?php endif; ?>
                    <?php endif; ?>

                </td>
                <td>
                    <?php if(isset($interview['interviewСomments'])): ?>
                        <input type="text" name="interviewComments_<?php echo e($interview['id'] ?? ''); ?>"
                               value="<?php echo e($interview['interviewСomments'] ?? ''); ?>"
                               class="form-control">
                    <?php endif; ?>
                </td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php endif; ?>
<?php /**PATH /home/servers/simpatik/resources/views/hr/person_info_form_interview.blade.php ENDPATH**/ ?>