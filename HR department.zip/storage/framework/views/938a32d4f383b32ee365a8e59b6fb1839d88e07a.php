<div class="py-3 d-block">
    <div class="card">
        <div class="row no-gutters">

            <?php if(empty(!$image)): ?>
                <div class="col-md-3">
                    <div class="h-100" style="display: contents">
                        <img src="<?php echo e($image); ?>" class="img-fluid img-card">
                    </div>
                </div>
            <?php endif; ?>

            <div class="col">
                <div class="card-body h-full">
                    <div class="row d-flex align-items-center">
                        <div class="col-auto">
                            <h5 class="card-title">
                                <?php if(empty(!$color)): ?><i class="text-<?php echo e($color); ?>">●</i><?php endif; ?>
                                <?php echo e($title ?? ''); ?>

                            </h5>
                        </div>

                        <?php if(count($commandBar) > 0): ?>
                            <div class="col-auto ml-auto text-right">
                                <div class="btn-group command-bar">
                                    <button class="btn btn-link btn-sm dropdown-toggle dropdown-item p-2" type="button"
                                            data-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false">
                                        <i class="icon-options-vertical"></i>
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow bg-white"
                                         x-placement="bottom-end">
                                        <?php $__currentLoopData = $commandBar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $command): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $command; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-text"><?php echo $description ?? ''; ?></div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/layouts/card.blade.php ENDPATH**/ ?>