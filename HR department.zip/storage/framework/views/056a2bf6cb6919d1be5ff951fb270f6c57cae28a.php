<?php if(isset($question['question'])): ?>
    <h6><?php echo e($question['question'] ?? ''); ?>

        <br><?php echo e($question['answer'] ?? ''); ?></h6>
    <hr width="100px" align="left">
<?php endif; ?>
<?php /**PATH /home/servers/simpatik/resources/views/hr/application_form/application_form_html_show_part.blade.php ENDPATH**/ ?>