<?php if(empty(!Dashboard::getSearch()->all())): ?>
    <div class="p-3">
        <div class="dropdown position-relative" data-controller="layouts--search">
            <div class="input-icon">
                <input
                    data-action="keyup->layouts--search#query blur->layouts--search#blur focus->layouts--search#focus"
                    data-target="layouts--search.query"
                    type="text"
                    value="<?php echo $__env->yieldContent('search'); ?>"
                       class="form-control input-sm padder bg-dark text-white"
                       placeholder="<?php echo e(__('What to search...')); ?>"
                >
                <div class="input-icon-addon">
                    <i class="icon-magnifier"></i>
                </div>
            </div>
            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow bg-white w-100"
                 x-placement="start-left" id="search-result">
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/partials/search.blade.php ENDPATH**/ ?>