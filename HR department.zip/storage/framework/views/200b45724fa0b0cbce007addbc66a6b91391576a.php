<div class="pt-0" data-async>

    <p>
        <a data-toggle="collapse"
           href="#collapse-<?php echo e($slug); ?>"
           role="button"
           aria-expanded="false"
           aria-controls="collapse-<?php echo e($slug); ?>">
           <?php echo e(__($label)); ?>

        </a>
    </p>
    <div class="collapse" id="collapse-<?php echo e($slug); ?>">
        <?php echo $form ?? ''; ?>

    </div>

</div>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/layouts/collapse.blade.php ENDPATH**/ ?>