<?php if(isset($title)): ?>
    <li class="nav-item mt-3">
        <div class="hidden-folded padder mt-1 mb-1 text-muted text-xs m-l"><?php echo e(__($title)); ?></div>
    </li>
<?php endif; ?>

<li class="nav-item <?php if(isset($active)): ?> <?php echo e(active($active)); ?> <?php endif; ?>">
    <a class="nav-link"
       <?php if(!empty($childs)): ?>
       href="#menu-<?php echo e($slug); ?>" data-toggle="collapse"
       <?php else: ?>
       href="<?php echo e($route ?? '#'); ?>"
        <?php endif; ?>
    >
        <?php if(isset($badge)): ?>
            <b class="badge bg-<?php echo e($badge['class']); ?> pull-right mr-3 mt-1"><?php echo e($badge['data']()); ?></b>
        <?php endif; ?>
        <i class="<?php echo e($icon); ?> mr-2"></i><?php echo e(__($label)); ?>

    </a>
</li>

<?php if($childs): ?>
    <div class="collapse sub-menu <?php echo e(active($active,'show')); ?>" id="menu-<?php echo e($slug); ?>" data-parent="#headerMenuCollapse">
        <?php echo Dashboard::menu()->render($slug,'platform::partials.dropdownMenu'); ?>

    </div>
<?php endif; ?>

<?php if($divider): ?>
    <li class="divider my-2"></li>
<?php endif; ?>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/partials/mainMenu.blade.php ENDPATH**/ ?>