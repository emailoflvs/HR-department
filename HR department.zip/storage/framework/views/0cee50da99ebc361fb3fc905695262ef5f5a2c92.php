<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" data-controller="layouts--html-load">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title','ORCHID'); ?> - <?php echo $__env->yieldContent('description','Admin'); ?></title>
    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" id="csrf_token" data-turbolinks-permanent>
    <meta name="auth" content="<?php echo e(Auth::check()); ?>"  id="auth" data-turbolinks-permanent>
    <?php if(file_exists(public_path('/css/orchid/orchid.css'))): ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/orchid/orchid.css')); ?>">
    <?php else: ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(orchid_mix('/css/orchid.css','orchid')); ?>">
    <?php endif; ?>

    <?php echo $__env->yieldPushContent('head'); ?>

    <meta name="turbolinks-root" content="<?php echo e(Dashboard::prefix()); ?>">
    <meta name="dashboard-prefix" content="<?php echo e(Dashboard::prefix()); ?>">

    <script src="<?php echo e(orchid_mix('/js/manifest.js','orchid')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(orchid_mix('/js/vendor.js','orchid')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(orchid_mix('/js/orchid.js','orchid')); ?>" type="text/javascript"></script>

    <?php $__currentLoopData = Dashboard::getResource('stylesheets'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stylesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <link rel="stylesheet" href="<?php echo e($stylesheet); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo $__env->yieldPushContent('stylesheets'); ?>

    <?php $__currentLoopData = Dashboard::getResource('scripts'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scripts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script src="<?php echo e($scripts); ?>" defer type="text/javascript"></script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</head>

<body>


<div class="app row m-n" id="app" data-controller="<?php echo $__env->yieldContent('controller'); ?>" <?php echo $__env->yieldContent('controller-data'); ?>>
    <div class="container-lg">
        <div class="row">
            <div class="aside col-xs-12 col-md-2 offset-xxl-0 col-xl-2 col-xxl-3 no-padder bg-dark">
                <div class="d-md-flex align-items-start flex-column d-sm-block h-full">
                    <?php echo $__env->yieldContent('body-left'); ?>
                </div>
            </div>
            <div class="col-md col-xl col-xxl-9 bg-white shadow no-padder min-vh-100 overflow-hidden">
                <?php echo $__env->yieldContent('body-right'); ?>
            </div>
        </div>
    </div>


<?php echo $__env->make('platform::partials.toast', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php echo $__env->yieldPushContent('scripts'); ?>


</body>
</html>
<?php /**PATH /home/dev/web/crm/vendor/orchid/platform/resources/views/app.blade.php ENDPATH**/ ?>