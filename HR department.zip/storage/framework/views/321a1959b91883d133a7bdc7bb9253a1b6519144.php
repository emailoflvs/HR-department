<?php if($status): ?>

    <div class="row">
        <div class="w-100 alert alert-warning m-n" role="alert">
            <p class="text-center">
                <a href="https://orchid.software">
                    <?php echo e(__('A new stable version of ORCHID is available. Please update to the latest version.')); ?>

                </a>
            </p>
        </div>
    </div>

<?php endif; ?>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/partials/update.blade.php ENDPATH**/ ?>