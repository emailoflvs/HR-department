<?php $__env->startPush('head'); ?>
    <link
          href="<?php echo e(route('platform.resource', ['orchid', 'favicon/orchid-pinned-tab.svg'])); ?>"
          id="favicon"
          rel="icon"
    >
<?php $__env->stopPush(); ?>

<div class="n-m font-thin v-center">
    <img src="/img/simpatik-logo.png"  width="50px">





</div>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/header.blade.php ENDPATH**/ ?>