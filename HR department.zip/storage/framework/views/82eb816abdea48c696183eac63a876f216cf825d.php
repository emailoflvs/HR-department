<?php echo $__env->make('.hr.person_application_form.html.application_form_html_div_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h5><?php echo e($question['question'] ?? ''); ?>

    <?php if($question['required'] != '0'): ?>
        <span style="color: red">*</span>
    <?php endif; ?>
</h5>
<h5><?php echo e($question['details']); ?></h5>
<textarea name="<?php echo e($question['vendorCode']); ?>"
          <?php if($question['required'] != '0'): ?>
          required
          <?php endif; ?>
          class="form-control" rows="4"></textarea>
<?php echo $__env->make('.hr.person_application_form.html.application_form_html_div_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/servers/simpatik/resources/views//hr/person_application_form/html/application_form_html_textarea.blade.php ENDPATH**/ ?>