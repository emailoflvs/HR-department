<!DOCTYPE html>
<html lang="ru" dir="ltr">
<head>
    <title>Симпатик админка - Welcome to Voyager. The Missing Admin for Laravel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="aTmmPBJBDRl4E2HmeOG2PNIWoKENZ1GKwNpkUtce"/>
    <meta name="assets-path" content="/admin/voyager-assets"/>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">

    <!-- Favicon -->
    <link rel="shortcut icon" href="/admin/voyager-assets?path=images%2Flogo-icon.png" type="image/png">



    <!-- App CSS -->
    <link rel="stylesheet" href="/admin/voyager-assets?path=css%2Fapp.css">


    <!-- Few Dynamic Styles -->
    <style type="text/css">
        .voyager .side-menu .navbar-header {
            background:#22A7F0;
            border-color:#22A7F0;
        }
        .widget .btn-primary{
            border-color:#22A7F0;
        }
        .widget .btn-primary:focus, .widget .btn-primary:hover, .widget .btn-primary:active, .widget .btn-primary.active, .widget .btn-primary:active:focus{
            background:#22A7F0;
        }
        .voyager .breadcrumb a{
            color:#22A7F0;
        }
    </style>


</head>

<body class="voyager ">






<div class="app-container">
    <div class="fadetoblack visible-xs"></div>
    <div class="row content-container">
        <nav class="navbar navbar-default navbar-fixed-top navbar-top">
            <div class="container-fluid">








                <ul class="nav navbar-nav  navbar-right ">
                    <li class="dropdown profile">
                        <a href="#" class="dropdown-toggle text-right" data-toggle="dropdown" role="button"
                           aria-expanded="false"><img src="http://simpatik/storage/users/July2020/MPRBne7JAm1Zif7GQMRh.jpg" class="profile-img"> <span
                                class="caret"></span></a>
                        <ul class="dropdown-menu dropdown-menu-animated">
                            <li class="profile-img">
                                <img src="http://simpatik/storage/users/July2020/MPRBne7JAm1Zif7GQMRh.jpg" class="profile-img">
                                <div class="profile-body">
                                    <h5>Admin</h5>
                                    <h6>admin@admin.com</h6>
                                </div>
                            </li>
                            <li class="divider"></li>






                            <li >
                                <a href="/" target="_blank">
                                    <i class="voyager-home"></i>
                                    Главная
                                </a>
                            </li>
                            <li >
                                <form action="http://simpatik/admin/logout" method="POST">
                                    <input type="hidden" name="_token" value="aTmmPBJBDRl4E2HmeOG2PNIWoKENZ1GKwNpkUtce">
                                    <button type="submit" class="btn btn-danger btn-block">
                                        <i class="voyager-power"></i>
                                        Выход
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>































        <script>
            (function(){
                var appContainer = document.querySelector('.app-container'),
                    sidebar = appContainer.querySelector('.side-menu'),
                    navbar = appContainer.querySelector('nav.navbar.navbar-top'),
                    loader = document.getElementById('voyager-loader'),
                    hamburgerMenu = document.querySelector('.hamburger'),
                    sidebarTransition = sidebar.style.transition,
                    navbarTransition = navbar.style.transition,
                    containerTransition = appContainer.style.transition;

                sidebar.style.WebkitTransition = sidebar.style.MozTransition = sidebar.style.transition =
                    appContainer.style.WebkitTransition = appContainer.style.MozTransition = appContainer.style.transition =
                        navbar.style.WebkitTransition = navbar.style.MozTransition = navbar.style.transition = 'none';

                if (window.innerWidth > 768 && window.localStorage && window.localStorage['voyager.stickySidebar'] == 'true') {
                    appContainer.className += ' expanded no-animation';
                    loader.style.left = (sidebar.clientWidth/2)+'px';
                    hamburgerMenu.className += ' is-active no-animation';
                }

                navbar.style.WebkitTransition = navbar.style.MozTransition = navbar.style.transition = navbarTransition;
                sidebar.style.WebkitTransition = sidebar.style.MozTransition = sidebar.style.transition = sidebarTransition;
                appContainer.style.WebkitTransition = appContainer.style.MozTransition = appContainer.style.transition = containerTransition;
            })();
        </script>
        <!-- Main Content -->
        <div class="container-fluid">
            <div class="side-body padding-top">
                <div id="voyager-notifications"></div>
                <div class="page-content">
                    <div class="alerts">
                    </div>
                    <div class="analytics-container">

                        <h3 style="border-radius:4px; padding:20px; background:#fff; margin:0; color:#999; text-align:center;">
                            Основной контент
                        </h3>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<footer class="app-footer">
    <div class="site-footer-right">
        Сделано с <i class="voyager-heart"></i>  <a href="http://thecontrolgroup.com" target="_blank">The Control Group</a>
        - v1.4.2
    </div>
</footer>

<!-- Javascript Libs -->


<script type="text/javascript" src="http://simpatik/admin/voyager-assets?path=js%2Fapp.js"></script>

<script>

</script>
<script>










































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































</script>
<style>
    .dd-placeholder {
        flex: 1;
        width: 100%;
        min-width: 200px;
        max-width: 250px;
    }
</style>



</body>
</html>


<?php /**PATH /home/servers/simpatik/resources/views/menu.blade.php ENDPATH**/ ?>
