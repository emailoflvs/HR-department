<?php if(!isset($innerLoop)): ?>




        <?php else: ?>













<?php endif; ?>

                
                <?php

                    if (Voyager::translatable($items)) {
                        $items = $items->load('translations');
                    }

                ?>


                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php
                        $originalItem = $item;
                        if (Voyager::translatable($item)) {
                            $item = $item->translate($options->locale);
                        }

                        //var_dump($item['icon_class']);
                //exit;
                        $listItemClass = null;
                        $linkAttributes =  null;
                        $styles = null;
                        $icon = null;
                            $caret = null;

                        // Background Color or Color
                        if (isset($options->color) && $options->color == true) {
                            $styles = 'color:'.$item->color;
                        }
                        if (isset($options->background) && $options->background == true) {
                            $styles = 'background-color:'.$item->color;
                        }

                        // Set Icon
                        if(isset($options->icon) && $options->icon == true){
                            $icon = '<i class="icon ' . $item->icon_class . '"></i>';
                        }elseif($item['icon_class']){
                            $icon = '<i class="icon ' . $item['icon_class'] . '"></i>';
                        }

                        // With Children Attributes
                        if(!$originalItem->children->isEmpty()) {
                            $linkAttributes =  'class="dropdown-toggle" data-toggle="dropdown"';
                            $caret = '<span class="caret"></span>';

                            if(url($item->link()) == url()->current()){
                                $listItemClass = 'dropdown active';
                            }else{
                                $listItemClass = 'dropdown';
                            }
                        }
                    ?>

                    <?php if(!$originalItem->children->isEmpty()): ?>
                        <li class="dropdown">
                            <a target="_self" href="#<?php echo e(count($originalItem->children)); ?>-dropdown-element"
                               data-toggle="collapse"
                               aria-expanded="true" class="">
                                <span><?php echo $icon; ?></span>
                                <span
                                    class="title" style="text-transform:none;"><?php echo e($item->title); ?></span></a>
                            <div id="<?php echo e(count($originalItem->children)); ?>-dropdown-element"
                                 class="panel-collapse collapse in" aria-expanded="true" style="">
                                <div class="panel-body">
                                    <ul class="nav navbar-nav">
                                        
                                        
                                        


                                        <?php $__currentLoopData = $originalItem->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="">
                                                <a href="<?php echo e(url($child->link())); ?>" target="<?php echo e($child->target); ?>"
                                                   style="<?php echo e($styles); ?>" <?php echo $linkAttributes ?? ''; ?>>
                                                    <span><i class="icon <?php echo e($child['icon_class']); ?> "></i></span>
                                                    <span class="title"
                                                          style="text-transform:none;"><?php echo e($child->title); ?></span>
                                                    <?php echo $caret; ?>

                                                </a>
                                                <?php if(!$child->children->isEmpty()): ?>
                                                    
                                                    <?php echo $__env->make('navigation.left_menu_custom', ['items' => $child->children, 'options' => $options, 'innerLoop' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <?php endif; ?>
                                            </li>

                                            
                                            



                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php

                                                    ?>
                                                </ul>
                                    <?php else: ?>

                        
                        

                        

                        <li class="<?php echo e($listItemClass); ?>">
                            <a href="<?php echo e(url($item->link())); ?>" target="<?php echo e($item->target); ?>"
                               style="<?php echo e($styles); ?>" <?php echo $linkAttributes ?? ''; ?>>
                                <span><?php echo $icon; ?></span>
                                <span class="title" style="text-transform:none;"><?php echo e($item->title); ?></span>
                                <?php echo $caret; ?>

                            </a>
                            <?php if(!$originalItem->children->isEmpty()): ?>
                                
                                <?php echo $__env->make('navigation.left_menu_custom', ['items' => $originalItem->children, 'options' => $options, 'innerLoop' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </li>

                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(!isset($innerLoop)): ?>

       <?php else: ?>

                        </ul>
                        </div>
                    </div>
                </li>

<?php endif; ?>
<?php /**PATH /home/servers/simpatik/resources/views/navigation/left_menu_custom.blade.php ENDPATH**/ ?>