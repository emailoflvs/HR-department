<fieldset class="py-3" data-async>

    <?php if(empty(!$title)): ?>
        <div class="col p-0">
            <legend class="text-black"><?php echo e($title); ?></legend>
        </div>
    <?php endif; ?>

    <?php echo $form ?? ''; ?>

</fieldset>
<?php /**PATH /home/dev/web/crm/vendor/orchid/platform/resources/views/layouts/row.blade.php ENDPATH**/ ?>