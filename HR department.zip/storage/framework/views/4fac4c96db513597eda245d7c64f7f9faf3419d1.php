<?php if(isset($question['question'])): ?>
    <h6 style="color:#777; "><?php echo e($question['question'] ?? ''); ?><br>
        <?php if($question['answer'] == 'on'): ?>
            Да
        <?php else: ?>
            Нет
        <?php endif; ?>
    </h6>
    <hr width="100px" align="left">
    <hr width="100px" align="left">
<?php endif; ?>
<?php /**PATH /home/servers/simpatik/resources/views/hr/application_form/html/application_form_html_show_radio.blade.php ENDPATH**/ ?>