<div class="text-center">
    <p class="small m-n">
      <?php echo e(__('The application code is published under the MIT license.')); ?> 2016 - <?php echo e(date('Y')); ?><br>
        <a href="http://orchid.software" target="_blank" rel="noopener">
            <?php echo e(__('Currently')); ?> v<?php echo e(\Orchid\Platform\Dashboard::VERSION); ?>

        </a>
    </p>
</div><?php /**PATH /home/dev/web/crm/vendor/orchid/platform/resources/views/footer.blade.php ENDPATH**/ ?>