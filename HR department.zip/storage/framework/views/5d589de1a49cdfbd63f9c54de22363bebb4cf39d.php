<div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6">
        <div class="panel panel-bordered">
            <div class="panel-body" style="padding:30px;">
                <div class="dd col-md-3">

<?php /**PATH /home/servers/simpatik/resources/views/hr/application_form/html/application_form_html_div_header.blade.php ENDPATH**/ ?>