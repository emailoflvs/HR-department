<?php $__env->startComponent($typeForm, get_defined_vars()); ?>

    <div    data-controller="fields--password"
            class="input-icon"
    >
        <input <?php call_user_func(function ($attributes) {
                foreach ($attributes as $name => $value) {
                    if (is_null($value)) {
                        continue;
                    }

                    if (is_bool($value) && $value === false) {
                        continue;
                    }
                    if (is_bool($value)) {
                        echo e($name)." ";
                        continue;
                    }

                    if (is_array($value)) {
                        echo json_decode($value)." ";
                        continue;
                    }

                    echo e($name) . '="' . e($value) . '"'." ";
                }
            }, $attributes); ?> data-target="fields--password.password">
        <div class="input-icon-addon cursor" data-action="click->fields--password#change">
            <i class="icon-eye" data-target="fields--password.icon"></i>
        </div>
    </div>

<?php if (isset($__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d)): ?>
<?php $component = $__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d; ?>
<?php unset($__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/fields/password.blade.php ENDPATH**/ ?>