<div class="side-menu sidebar-inverse">
    <nav class="navbar navbar-default" role="navigation">
        <div class="side-menu-container">
            <div class="navbar-header">
                <a class="navbar-brand" href="/">
                    <div class="logo-icon-container">
                        <img src="/admin/voyager-assets?path=images%2Flogo-icon-light.png" alt="Logo Icon">
                    </div>
                    <div class="title"><?php echo setting('site.title'); ?></div>
                </a>
            </div>
            
            
            
            
            
            
            
            
            

            
            
            
            

        </div>
        <div id="adminmenu">

            
            
            

            <ul class="nav navbar-nav">

                














                
                
                



                

                

                
                <?php echo menu('hr_left_menu','navigation.left_menu_custom'); ?>


                
                

                <?php
                    $workingStatus = new \App\WorkingStatus();

                //если в очереди, то показываем меню
                if ($workingStatus->GetCurrentUserWorkingStatus()){
                ?>

                
                

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                


                
                
                
                


                <?php
                    }
                ?>

                

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                


                
                
                

                
                
                
                
                
                
                
                
                

                
                
            </ul>


            

        </div>
        
        
        

        
        


    </nav>
</div>























<?php /**PATH /home/servers/simpatik/resources/views/navigation/left_menu.blade.php ENDPATH**/ ?>