<div class="p-3 v-center">
    <div class="dropdown col no-padder">
        <a href="#" class="nav-link p-0 v-center" data-toggle="dropdown">
            <?php if($image = Auth::user()->presenter()->image()): ?>
                <span class="thumb-sm avatar mr-3">
                        <img src="<?php echo e($image); ?>" class="b b-dark bg-light">
                </span>
            <?php endif; ?>
            <span style="width:11em;font-size: 0.85em;">
                <span class="text-ellipsis"><?php echo e(Auth::user()->presenter()->title()); ?></span>
                <span class="text-muted d-block text-ellipsis"><?php echo e(Auth::user()->presenter()->subTitle()); ?></span>
            </span>
        </a>
        <div class="dropdown-menu dropdown-menu-left dropdown-menu-arrow bg-white">

            <?php echo Dashboard::menu()->render('Profile','platform::partials.dropdownMenu'); ?>


            <?php if(Dashboard::menu()->container->where('location','Profile')->isNotEmpty()): ?>
                <div class="dropdown-divider"></div>
            <?php endif; ?>

            <?php if(Auth::user()->hasAccess('platform.systems.index')): ?>
                <a href="<?php echo e(route('platform.systems.index')); ?>" class="dropdown-item">
                    <i class="icon-settings mr-2" aria-hidden="true"></i>
                    <span><?php echo e(__('Systems')); ?></span>
                </a>
            <?php endif; ?>

            <?php if(\Orchid\Access\UserSwitch::isSwitch()): ?>
                <a href="#"
                   class="dropdown-item"
                   data-controller="layouts--form"
                   data-action="layouts--form#submitByForm"
                   data-layouts--form-id="return-original-user"
                >
                    <i class="icon-logout mr-2" aria-hidden="true"></i>
                    <span><?php echo e(__('Back to my account')); ?></span>
                </a>
                <form id="return-original-user"
                      class="hidden"
                      data-controller="layouts--form"
                      data-action="layouts--form#submit"
                      action="<?php echo e(route('platform.switch.logout')); ?>"
                      method="POST">
                    <?php echo csrf_field(); ?>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('platform.logout')); ?>"
                   class="dropdown-item"
                   data-controller="layouts--form"
                   data-action="layouts--form#submitByForm"
                   data-layouts--form-id="logout-form"
                   dusk="logout-button">
                    <i class="icon-logout mr-2" aria-hidden="true"></i>
                    <span><?php echo e(__('Sign out')); ?></span>
                </a>
                <form id="logout-form"
                      class="hidden"
                      action="<?php echo e(route('platform.logout')); ?>"
                      method="POST"
                      data-controller="layouts--form"
                      data-action="layouts--form#submit"
                >
                    <?php echo csrf_field(); ?>
                </form>
            <?php endif; ?>

        </div>
    </div>

    <?php echo $__env->make('platform::partials.notificationProfile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/dev/web/crm/vendor/orchid/platform/resources/views/partials/profile.blade.php ENDPATH**/ ?>