<?php
    session_start();
?><!DOCTYPE html>
<html lang="ru">

<head>
    <title><?php echo setting('site.title'); ?></title>
    
    
    <meta name="assets-path" content="/admin/voyager-assets"/>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">

    <!-- Favicon -->
    <link rel="shortcut icon" href="/admin/voyager-assets?path=images%2Flogo-icon.png" type="image/png">

    
    
    
    
    

    

    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <!-- App CSS -->
    <link rel="stylesheet" href="/admin/voyager-assets?path=css%2Fapp.css">

    <!-- Few Dynamic Styles -->
    <style type="text/css">
        .voyager .side-menu .navbar-header {
            background: #22A7F0;
            border-color: #22A7F0;
        }

        .widget .btn-primary {
            border-color: #22A7F0;
        }

        .widget .btn-primary:focus, .widget .btn-primary:hover, .widget .btn-primary:active, .widget .btn-primary.active, .widget .btn-primary:active:focus {
            background: #22A7F0;
        }

        .voyager .breadcrumb a {
            color: #22A7F0;
        }


    </style>

</head>
<?php /**PATH /home/servers/simpatik/resources/views/layouts/header.blade.php ENDPATH**/ ?>