<footer class="pb-3 w-100">
    <div class="v-md-center">
        <div class="col-sm-5">
            <?php if($paginator instanceof \Illuminate\Contracts\Pagination\LengthAwarePaginator): ?>

                <?php if(isset($columns) && \Orchid\Screen\TD::isShowVisibleColumns($columns)): ?>
                    <div class="btn-group dropup d-inline-block">
                        <button type="button"
                                class="btn btn-sm btn-link dropdown-toggle p-0 m-0"
                                data-toggle="dropdown"
                                aria-haspopup="true"
                                aria-expanded="false">
                            <?php echo e(__('Configure columns')); ?>

                        </button>
                        <div class="dropdown-menu dropdown-column-menu">
                            <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $column->buildItemMenu(); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <small class="text-muted block">
                    <?php echo e(__('Displayed records: :from-:to of :total',[
                        'from' => ($paginator->currentPage() -1 ) * $paginator->perPage() + 1,
                        'to' => ($paginator->currentPage() -1 ) * $paginator->perPage() + count($paginator->items()),
                        'total' => $paginator->total(),
                    ])); ?>

                </small>
            <?php endif; ?>

        </div>
        <div class="col-sm-7 text-right text-center-xs">
            <?php echo $paginator->appends(request()->except(['page','_token']))->links('platform::partials.pagination'); ?>

        </div>
    </div>
</footer>
<?php /**PATH /home/dev/web/crm/vendor/orchid/platform/resources/views/layouts/pagination.blade.php ENDPATH**/ ?>