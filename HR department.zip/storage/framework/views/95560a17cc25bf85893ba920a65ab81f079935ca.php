<div class="form-group v-center">
    <span class="thumb-sm avatar mr-3">
        <img src="<?php echo e($lockUser->presenter()->image()); ?>" class="b bg-light" alt="test">
    </span>
    <span style="width:125px;font-size: 0.85em;">
        <span class="text-ellipsis"><?php echo e($lockUser->presenter()->title()); ?></span>
        <span class="text-muted d-block text-ellipsis"><?php echo e($lockUser->presenter()->subTitle()); ?></span>
    </span>
    <input type="hidden" name="email" required value="<?php echo e($lockUser->email); ?>">
</div>

<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="d-block invalid-feedback text-danger">
            <?php echo e($errors->first('email')); ?>

    </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

<div class="form-group">
    <input type="hidden" name="remember" value="true">

    <?php echo \Orchid\Screen\Fields\Password::make('password')
            ->required()
            ->tabindex(1)
            ->autofocus()
            ->placeholder(__('Enter your password')); ?>

</div>

<div class="row">
    <div class="form-group col-md-6 col-xs-12">
        <a href="<?php echo e(route('platform.login.lock')); ?>" class="small">
            <?php echo e(__('Sign in with another user.')); ?>

        </a>
    </div>
    <div class="form-group col-md-6 col-xs-12">
        <button id="button-login" type="submit" class="btn btn-default btn-block" tabindex="2">
            <i class="icon-login text-xs mr-2"></i> <?php echo e(__('Login')); ?>

        </button>
    </div>
</div>
<?php /**PATH /home/dev/web/crm/vendor/orchid/platform/resources/views/auth/lockme.blade.php ENDPATH**/ ?>