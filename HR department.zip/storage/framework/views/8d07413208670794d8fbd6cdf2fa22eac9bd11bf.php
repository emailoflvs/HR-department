<?php echo $__env->make('hr.application_form.html.application_form_html_div_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h5>
    <?php echo e($questions[$question]['question'] ?? ''); ?>


    <?php if(isset($notRequired)): ?>
        
    <?php else: ?>
        <span style="color: red">*</span>
    <?php endif; ?>
</h5>
<input type="text" name="<?php echo e($question); ?>"
       <?php if(isset($notRequired)): ?>
       
       <?php else: ?>
       required
       <?php endif; ?>
       class="form-control" placeholder="" value="">
<?php echo $__env->make('hr.application_form.html.application_form_html_div_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/servers/simpatik/resources/views/hr/application_form/html/application_form_html_input.blade.php ENDPATH**/ ?>