<?php echo $__env->make('hr.application_form.application_form_html_div_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h5>
    <?php echo e($questions[$question]['question'] ?? ''); ?>

    <span style="color: red">*</span></h5>
<select name="<?php echo e($question); ?>" id="<?php echo e($question); ?>"
        required class="form-control"
    
>
    <option></option>
    <?php if(isset($questions[$question]['answers'])): ?>
        <?php $__currentLoopData = $questions[$question]['answers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($answer['id']); ?>">
                <?php echo e($answer['answer']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</select>
<?php echo $__env->make('hr.application_form.application_form_html_div_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/servers/simpatik/resources/views/hr/application_form/application_form_html_select.blade.php ENDPATH**/ ?>