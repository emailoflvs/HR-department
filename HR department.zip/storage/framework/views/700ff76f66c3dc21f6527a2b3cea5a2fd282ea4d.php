<?php $__env->startSection('content'); ?>



    <h1 class="page-title">
        <i class="voyager-person"></i> Список кандидатов
    </h1>
    <div id="voyager-notifications"></div>

    <div class="page-content container-fluid">
        <div class="row">
            <div id="dbManager" class="col-md-12">

                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th width="10%">Дата</th>
                        <th>ФИО</th>
                        <th>Номер телефона</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="newTableRow">
                        <td>
                            <?php echo e($person->date_added_to_database ?? ''); ?>

                        </td>
                        <td>
                            <a href=""><?php echo e($person->surname ?? ''); ?> <?php echo e($person->name ?? ''); ?></a>
                        </td>

                        <td>
                            <?php echo e($person->phone_number ?? ''); ?>

                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>




                <form action="http://simpatik/admin/database/menus" method="POST">
                    <input type="hidden" name="_method" value="PUT">
                    <div class="panel panel-bordered">









                            <div id="alertsContainer"></div>

                            <table class="table table-bordered" style="width: 100%;">
                                <thead>
                                <tr>
                                    <th>Дата</th>
                                    <th>ФИО</th>
                                    <th>Номер</th>
                                    <th>Действие</th>
                                    <th>Источник</th>
                                    <th>Результат</th>
                                    <th>Мессенджер</th>
                                    <th>Отклик по рассылке</th>
                                    <th>Причина отказа</th>
                                    <th>Конкретизация причины</th>
                                    <th>Дата</th>
                                    <th>Время</th>
                                    <th>Предпочтительный график</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr class="newTableRow">
                                    <td>





                                        <input type="date" min="2001-01-01" name="register_date" class="form-control"
                                               value="
                                        <?php if(isset($start_date)): ?>
                                                   <?php echo e($start_date); ?>

                                        <?php endif; ?>">

                                    </td>
                                    <td>
                                        <input type="text" required="required" pattern="^[a-zA-Z_][a-zA-Z0-9_]*$"
                                               class="form-control">
                                    </td>
                                    <td>
                                        <div><select class="form-control">
                                                <optgroup label="Numbers">
                                                    <option value="tinyint">
                                                        TINYINT
                                                    </option>
                                                    <option value="smallint">
                                                        SMALLINT
                                                    </option>
                                                    <option value="mediumint">
                                                        MEDIUMINT
                                                    </option>
                                                    <option value="integer">
                                                        INTEGER
                                                    </option>
                                                    <option value="bigint">
                                                        BIGINT
                                                    </option>
                                                    <option value="float">
                                                        FLOAT
                                                    </option>
                                                    <option value="double">
                                                        DOUBLE
                                                    </option>
                                                    <option value="decimal">
                                                        DECIMAL
                                                    </option>
                                                </optgroup>
                                                <optgroup label="Strings">
                                                    <option value="tinytext">
                                                        TINYTEXT
                                                    </option>
                                                    <option value="mediumtext">
                                                        MEDIUMTEXT
                                                    </option>
                                                    <option value="longtext">
                                                        LONGTEXT
                                                    </option>
                                                    <option value="text">
                                                        TEXT
                                                    </option>
                                                    <option value="varchar">
                                                        VARCHAR
                                                    </option>
                                                    <option value="char">
                                                        CHAR
                                                    </option>
                                                </optgroup>
                                                <optgroup label="Date and Time">
                                                    <option value="date">
                                                        DATE
                                                    </option>
                                                    <option value="datetime">
                                                        DATETIME
                                                    </option>
                                                    <option value="timestamp">
                                                        TIMESTAMP
                                                    </option>
                                                    <option value="time">
                                                        TIME
                                                    </option>
                                                    <option value="year">
                                                        YEAR
                                                    </option>
                                                </optgroup>
                                                <optgroup label="Binary">
                                                    <option value="longblob">
                                                        LONGBLOB
                                                    </option>
                                                    <option value="blob">
                                                        BLOB
                                                    </option>
                                                    <option value="mediumblob">
                                                        MEDIUMBLOB
                                                    </option>
                                                    <option value="tinyblob">
                                                        TINYBLOB
                                                    </option>
                                                    <option value="binary">
                                                        BINARY
                                                    </option>
                                                    <option value="varbinary">
                                                        VARBINARY
                                                    </option>
                                                    <option value="bit">
                                                        BIT
                                                    </option>
                                                </optgroup>
                                                <optgroup label="Lists">
                                                    <option disabled="disabled" value="set">
                                                        SET
                                                    </option>
                                                    <option value="json">
                                                        JSON
                                                    </option>
                                                    <option disabled="disabled" value="enum">
                                                        ENUM
                                                    </option>
                                                </optgroup>
                                                <optgroup label="Geometry">
                                                    <option value="geometrycollection">
                                                        GEOMETRYCOLLECTION
                                                    </option>
                                                    <option value="geometry">
                                                        GEOMETRY
                                                    </option>
                                                    <option value="linestring">
                                                        LINESTRING
                                                    </option>
                                                    <option value="multilinestring">
                                                        MULTILINESTRING
                                                    </option>
                                                    <option value="multipoint">
                                                        MULTIPOINT
                                                    </option>
                                                    <option value="multipolygon">
                                                        MULTIPOLYGON
                                                    </option>
                                                    <option value="point">
                                                        POINT
                                                    </option>
                                                    <option value="polygon">
                                                        POLYGON
                                                    </option>
                                                </optgroup>
                                            </select> <!----></div>
                                    </td>
                                    <td><input type="number" min="0" class="form-control"></td>
                                    <td><input type="checkbox"></td>
                                    <td><input type="checkbox"></td>
                                    <td><input type="checkbox"></td>

                                    <td><select class="form-control">
                                            <option value=""></option>
                                            <option value="INDEX">INDEX</option>
                                            <option value="UNIQUE">UNIQUE</option>
                                            <option value="PRIMARY">ПЕРВИЧНЫЙ КЛЮЧ</option>
                                        </select> <!----></td>
                                    <td><input type="number" step="any" class="form-control"></td>
                                    <td>
                                        <div class="btn btn-danger delete-row"><i class="voyager-trash"></i></div>
                                    </td>
                                </tr>

                                </tbody>
                            </table>
                            <div style="text-align: center;">
                                <div>
                                    <div class="btn btn-success">+ Добавить новый столбец</div>
                                    <div class="btn btn-success">+ Добавить метки времени</div>
                                    <div class="btn btn-success">+ Добавить Soft Deletes</div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer"><input type="submit" value="Обновить таблицу"
                                                         class="btn btn-primary pull-right">
                            <div style="clear: both;"></div>
                        </div>
                    </div>
                    <input type="hidden" name="table"> <input type="hidden" name="_token"
                                                              value="325CSuFjONbmIBlO6VZovErh3nQRflo1qpWktNC9"></form>
            </div>
        </div>








    <!-- /.modal -->





























































































































































































































































































































































































































































































































































































































































































































































































































































































<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/servers/simpatik/resources/views/hr/people_list.blade.php ENDPATH**/ ?>
