<?php echo $__env->make('.hr.person_application_form.html.application_form_html_div_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="<?php echo e($question['vendorCode']); ?>" style="display: none; color:red;">
    <h5>Заполните поле:</h5></div>
<h5><?php echo e($question['question'] ?? ''); ?>


<?php if(isset($notRequired)): ?>
    не требуем обязательного заполнения, если есть $required
<?php else: ?>
    <span style="color: red">*</span>
<?php endif; ?>
</h5>
Абсолютно не важно
<?php for($i = 1; $i <= 10; $i++): ?>
    <div class="form_radio_btn">
        <input id="<?php echo e($question['vendorCode']); ?>-<?php echo e($i); ?>" type="radio" name="<?php echo e($question['vendorCode']); ?>"
               value="<?php echo e($i); ?>" required>
        <label for="<?php echo e($question['vendorCode']); ?>-<?php echo e($i); ?>"><?php echo e($i); ?></label>
    </div>
<?php endfor; ?>
Очень важно
<script>
    $(document.getElementsByName('<?php echo e($question['vendorCode']); ?>')).change(function () {
        $('#' + '<?php echo e($question['vendorCode']); ?>').hide();
    });
</script>




















<?php echo $__env->make('.hr.person_application_form.html.application_form_html_div_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/servers/simpatik/resources/views//hr/person_application_form/html/application_form_html_radio_horizontal2.blade.php ENDPATH**/ ?>