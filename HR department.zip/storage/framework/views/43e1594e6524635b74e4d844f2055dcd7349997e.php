<div class="py-3">
    <div class="alert alert-warning">
        Two Factor Authentication is Currently <strong>Enabled</strong> for your account.
    </div>
    Your account is more secure when you need a password and a verification code to sign in.
    If you remove this extra layer of security, you will only be asked for a password when you sign in.
    It might be easier for someone to break into your account.
</div>

<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/auth/settings/disable-two-factor-auth.blade.php ENDPATH**/ ?>