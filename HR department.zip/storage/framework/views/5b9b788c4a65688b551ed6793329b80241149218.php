<?php $__env->startSection('content'); ?>


    
    <h1 class="page-title">
        <i class="voyager-telephone"></i> Мои планируемые звонки
    </h1>
    <div id="voyager-notifications"></div>

    <div class="page-content container-fluid">
        <div class="row">
            <div id="dbManager" class="col-md-12">

                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th width="10%">Время</th>
                        <th>Кандидат</th>
                        <th>Номер телефона</th>
                        <th>Причина звонка</th>
                        <th>Менеджер</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(isset($calendar)): ?>

                        <?php $__currentLoopData = $calendar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $calls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="10">
                                    <h5><?php echo e($day ?? 'day'); ?></h5>
                                </td>
                            </tr>

                            <?php if(isset($calls)): ?>
                                <?php $__currentLoopData = $calls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $call): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr class="newTableRow">
                                        <td style="white-space: nowrap;">

                                            
                                            
                                            
                                            <?php echo e($call['planActionTime']); ?>

                                        </td>
                                        <td>
                                            <a href="/hr_person_edit/<?php echo e($call['person']['id']); ?>">
                                                <?php echo e($call['person']['surname'] ?? ''); ?> <?php echo e($call['person']['name'] ?? ''); ?></a>
                                        </td>

                                        <td>
                                            <?php echo e($call['person']['phoneNumber'] ?? ''); ?>

                                        </td>
                                        <td>
                                            <?php echo e($call['reason']); ?>

                                        </td>

                                        <td>
                                            <?php if(isset($call['operator'])): ?>
                                                <?php echo e($call['operator']); ?>

                                            <?php endif; ?>

                                        </td>

                                        
                                        
                                        
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/servers/simpatik/resources/views/hr/operator/planned_calls.blade.php ENDPATH**/ ?>