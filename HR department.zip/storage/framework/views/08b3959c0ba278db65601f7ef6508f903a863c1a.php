<?php echo $__env->make('hr.application_form.application_form_html_div_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="<?php echo e($question); ?>" style="display: none; color:red;">
    <h5>Заполните поле:</h5></div>
<h5><?php echo e($questions[$question]['question'] ?? ''); ?>

    <span style="color: red">*</span></h5>
<table>
    <tr>
        <td>Абсолютно не важно&nbsp;&nbsp;</td>
        <td>
            <div class="form_radio_group">
                <?php for($i = 1; $i <= 10; $i++): ?>
                    <div class="form_radio_group-item">
                        <input id="<?php echo e($question); ?>-<?php echo e($i); ?>" type="radio"
                               name="<?php echo e($question); ?>" value="<?php echo e($i); ?>" required>
                        <label
                            for="<?php echo e($question); ?>-<?php echo e($i); ?>"><?php echo e($i); ?></label>
                    </div>
                <?php endfor; ?>
            </div>
        </td>
        <td>&nbsp;&nbsp;Очень важно</td>
    </tr>
</table>
<script>
    $(document.getElementsByName('<?php echo e($question); ?>')).change(function () {
        $('#' + '<?php echo e($question); ?>').hide();
    });
</script>
<?php echo $__env->make('hr.application_form.application_form_html_div_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH /home/servers/simpatik/resources/views/hr/application_form/application_form_html_radio_horizontal.blade.php ENDPATH**/ ?>
