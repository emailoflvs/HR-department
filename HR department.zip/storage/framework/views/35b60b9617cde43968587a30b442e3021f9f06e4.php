<?php echo $__env->make('modals.call_place_exit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<nav class="navbar navbar-default navbar-fixed-top navbar-top">

    <div class="container-fluid">

        <div class="navbar-header" style="white-space: nowrap;">


            <button class="hamburger btn-link">
                <span class="hamburger-inner"></span>
            </button>
            <ol class="breadcrumb hidden-xs">
                <li class="active"><i class="voyager-boat"></i> Панель управления</li>
            </ol>
            <ol class="breadcrumb hidden-xs">
                <li class="active"><i class="voyager-search"></i>
                    <input name="search" placeholder="Поиск">
                </li>
            </ol>

            
            
            
            
            
            
            
            
            


            <?php
                //контроллер не видит рабочую сессию, а только переключение кнопки,
                // поэтому меню отрабатываю здесь через модуль

//            if (isset ($request->all()['working_status']))--}}
//            if (isset ($working_status))
//                $working_status = $working_status;
//            else
//                $working_status = 0;

            //if (isset ($working_status))
              //  var_dump($working_status);
            //exit;

                    $workingStatus = new \App\WorkingStatus();

                    //если кнопку нажали, контроллер выдает номер статуса и мы добавляем его в сессию
               if (isset ($working_status))
                   $workingStatus->SetCurrentUserWorkingStatus($working_status);

               //если статус 0, то показываем "войти"
               if (!$workingStatus->GetCurrentUserWorkingStatus()){
            ?>
            <form name="working" action="/working" method="POST">
                <?php echo e(csrf_field()); ?>

                <button class="btn btn-success" style="margin-top:20px">
                    Стать в очередь
                </button>
                <input type="hidden" name="working_status" value="1">
            </form>
            <?php
                }
                else{
            ?>



            <span ><a href="javascript:;" title="Выйти"
                     class="btn btn-sm btn-warning pull-right call_place_exit" data-id="6" id="out-6"  style="margin-top:18px">
                    <span class="hidden-xs hidden-sm">Выйти</span></a></span>
          <?php
                }
            ?>






            


            
            
            
            
            
            

        </div>


<?php /**PATH /home/servers/simpatik/resources/views/navigation/top_menu.blade.php ENDPATH**/ ?>