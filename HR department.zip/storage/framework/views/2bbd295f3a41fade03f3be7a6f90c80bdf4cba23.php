<?php $__env->startComponent($typeForm, get_defined_vars()); ?>
    <?php if(isset($sendTrueOrFalse)): ?>
        <input hidden name="<?php echo e($attributes['name']); ?>" value="<?php echo e($attributes['novalue']); ?>">
        <div class="custom-control custom-checkbox">
            <input value="<?php echo e($attributes['yesvalue']); ?>"
                   <?php call_user_func(function ($attributes) {
                foreach ($attributes as $name => $value) {
                    if (is_null($value)) {
                        continue;
                    }

                    if (is_bool($value) && $value === false) {
                        continue;
                    }
                    if (is_bool($value)) {
                        echo e($name)." ";
                        continue;
                    }

                    if (is_array($value)) {
                        echo json_decode($value)." ";
                        continue;
                    }

                    echo e($name) . '="' . e($value) . '"'." ";
                }
            }, $attributes); ?>
                   <?php if(isset($attributes['value']) && $attributes['value']): ?> checked <?php endif; ?>
            >
            <label class="custom-control-label" for="<?php echo e($id); ?>"><?php echo e($placeholder ?? ''); ?></label>
        </div>
    <?php else: ?>
        <div class="custom-control custom-checkbox">
            <input <?php call_user_func(function ($attributes) {
                foreach ($attributes as $name => $value) {
                    if (is_null($value)) {
                        continue;
                    }

                    if (is_bool($value) && $value === false) {
                        continue;
                    }
                    if (is_bool($value)) {
                        echo e($name)." ";
                        continue;
                    }

                    if (is_array($value)) {
                        echo json_decode($value)." ";
                        continue;
                    }

                    echo e($name) . '="' . e($value) . '"'." ";
                }
            }, $attributes); ?>
                   <?php if(isset($attributes['value']) && $attributes['value'] && (!isset($attributes['checked']) || $attributes['checked'] !== false)): ?> checked <?php endif; ?>
            >
            <label class="custom-control-label" for="<?php echo e($id); ?>"><?php echo e($placeholder ?? ''); ?></label>
        </div>
    <?php endif; ?>
<?php if (isset($__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d)): ?>
<?php $component = $__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d; ?>
<?php unset($__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/fields/checkbox.blade.php ENDPATH**/ ?>