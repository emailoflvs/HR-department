<?php $__env->startComponent($typeForm, get_defined_vars()); ?>
    <div
        data-controller="fields--code"
        data-fields--code-language="<?php echo e($language); ?>"
        data-fields--code-line-numbers="<?php echo e($lineNumbers); ?>"
        data-fields--code-default-Theme="<?php echo e($defaultTheme); ?>"
    >
        <div class="code border pos-rlt w-100" style="min-height: <?php echo e($attributes['height']); ?>"></div>
        <input type="hidden" <?php call_user_func(function ($attributes) {
                foreach ($attributes as $name => $value) {
                    if (is_null($value)) {
                        continue;
                    }

                    if (is_bool($value) && $value === false) {
                        continue;
                    }
                    if (is_bool($value)) {
                        echo e($name)." ";
                        continue;
                    }

                    if (is_array($value)) {
                        echo json_decode($value)." ";
                        continue;
                    }

                    echo e($name) . '="' . e($value) . '"'." ";
                }
            }, $attributes); ?>>
    </div>
<?php if (isset($__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d)): ?>
<?php $component = $__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d; ?>
<?php unset($__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/fields/code.blade.php ENDPATH**/ ?>