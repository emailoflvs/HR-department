<a href="<?php echo e($url); ?>">
    <div class="d-sm-flex flex-row flex-wrap text-center text-sm-left align-items-center">
        <?php if(empty(!$image)): ?>
            <span class="thumb-sm avatar mr-sm-3 mr-md-0 mr-xl-3 d-none d-md-inline-block">
              <img src="<?php echo e($image); ?>" class="bg-light">
            </span>
        <?php endif; ?>
        <div class="mt-2 mt-sm-0 mt-md-2 mt-xl-0">
            <p class="mb-0"><?php echo e($title); ?></p>
            <small class="text-xs text-muted"><?php echo e($subTitle); ?></small>
        </div>
    </div>
</a>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/layouts/persona.blade.php ENDPATH**/ ?>