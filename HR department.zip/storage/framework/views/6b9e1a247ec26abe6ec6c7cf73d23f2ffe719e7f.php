<?php if(isset($interview['inviteResult'])): ?>

    <?php if($interview['inviteResult'] == 'invite'): ?>
        
        <?php if($interview['inviteResult'] == 'invite'): ?>
            <?php if(isset($interview['timetable']->timetable)): ?>
                <?php echo e($interview['timetable']->timetable ?? 'timetable'); ?>

            <?php endif; ?>

            <?php echo e($interview['specialization']->name ?? ''); ?>

        <?php endif; ?>

    <?php endif; ?>


    <?php if($interview['inviteResult'] == 'clarification'): ?>

        <?php if(isset($interview['inviteClarification']->reason)): ?>
            <?php echo e($interview['inviteClarification']->reason ?? ''); ?>

        <?php endif; ?>
        <?php if(isset($interview['inviteClarificationDetails'])): ?>
            <br>Подробнее: <?php echo e($interview['inviteClarificationDetails'] ?? ''); ?>

        <?php endif; ?>

        
        
        
        
        
    <?php endif; ?>

    <?php if(isset($interview['inviteResult'])): ?>
        <?php if($interview['inviteResult'] == 'refusing'): ?>
            <?php if(isset($interview['inviteRefusingReasonCompany'])): ?>
                От компании: <?php echo e($interview['inviteRefusingReasonCompany'] ?? ''); ?>

            <?php endif; ?>
            <?php if(isset($interview['inviteRefusingReasonCompanyDetails'])): ?>
                <br>От компании:<?php echo e($interview['inviteRefusingReasonCompanyDetails']  ?? ''); ?>

            <?php endif; ?>

            <?php if(isset($interview['inviteRefusingReasonPerson'])): ?>
                От кандидата: <?php echo e($interview['inviteRefusingReasonPerson'] ?? ''); ?>

            <?php endif; ?>
            <?php if(isset($interview['inviteRefusingReasonPersonDetails'])): ?>
                <br>От кандидата: <?php echo e($interview['inviteRefusingReasonPersonDetails'] ?? ''); ?>

            <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>

<?php /**PATH /home/servers/simpatik/resources/views/hr/person_status.blade.php ENDPATH**/ ?>