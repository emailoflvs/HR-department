<th width="<?php echo e($width); ?>" class="text-<?php echo e($align); ?>" data-column="<?php echo e($slug); ?>">
    <div>
        <?php if($sort): ?>
            <a href="<?php echo e($sortUrl); ?>"
               class="<?php if(!is_sort($column)): ?> text-muted <?php endif; ?>">
                <?php echo e($title); ?>


                <?php if(is_sort($column)): ?>
                    <i class="icon-sort-amount-<?php echo e(get_sort($column)); ?>"></i>
                <?php endif; ?>
            </a>
        <?php else: ?>
            <?php echo e($title); ?>

        <?php endif; ?>

        <?php echo $__env->renderWhen(!is_null($filter), "platform::partials.filters.{$filter}", get_defined_vars(), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
    </div>

    <?php if($filterString): ?>
        <div data-controller="screen--filter">
            <a href="#"
               data-action="screen--filter#clearFilter"
               data-filter="<?php echo e($column); ?>"
               class="badge badge-pill badge-light">
                <?php echo e($filterString); ?>

            </a>
        </div>
    <?php endif; ?>
</th>
<?php /**PATH /home/dev/web/crm/vendor/orchid/platform/resources/views/partials/layouts/th.blade.php ENDPATH**/ ?>