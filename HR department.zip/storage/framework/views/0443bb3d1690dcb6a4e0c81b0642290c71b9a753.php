<?php echo $__env->make('hr.application_form.html.application_form_html_div_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="<?php echo e($question); ?>" style="display: none; color:red;">
    <h5>Заполните поле:</h5></div>
<h5>
    <?php echo e($questions[$question]['question'] ?? ''); ?>

    <span style="color: red">*</span></h5>

<?php $__currentLoopData = $questions[$question]['answers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form_radio" id="<?php echo e($question); ?>">
        <input id="<?php echo e($question); ?>-<?php echo e($answer['id']); ?>" type="radio" name="<?php echo e($question); ?>"
               value="<?php echo e($answer['id']); ?>" required>
        <label for="<?php echo e($question); ?>-<?php echo e($answer['id']); ?>"><?php echo e($answer['answer']); ?></label>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    $(document.getElementsByName('<?php echo e($question); ?>')).change(function () {
        $('#' + '<?php echo e($question); ?>').hide();
    });
</script>
<?php echo $__env->make('hr.application_form.html.application_form_html_div_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/servers/simpatik/resources/views/hr/application_form/html/application_form_html_radio.blade.php ENDPATH**/ ?>