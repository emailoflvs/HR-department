<?php $__env->startSection('title',__($screen->name)); ?>
<?php $__env->startSection('description',__($screen->description)); ?>
<?php $__env->startSection('controller','screen--base'); ?>
<?php $__env->startSection('navbar'); ?>
    <?php $__currentLoopData = $commandBar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $command): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <?php echo $command; ?>

        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <form id="post-form"
              class="px-3"
              method="post"
              enctype="multipart/form-data"
              data-controller="layouts--form"
              data-action="keypress->layouts--form#disableKey
                           layouts--form#submit"
              data-layouts--form-validation="<?php echo e($screen->formValidateMessage()); ?>"
              novalidate
        >
            <?php echo $screen->build(); ?>

            <?php echo csrf_field(); ?>
        </form>
    <div id="modals-container">
        <?php echo $__env->yieldPushContent('modals-container'); ?>
    </div>
    <div data-controller="screen--filter">
        <form id="filters" autocomplete="off" data-action="screen--filter#submit"></form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('platform::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/layouts/base.blade.php ENDPATH**/ ?>