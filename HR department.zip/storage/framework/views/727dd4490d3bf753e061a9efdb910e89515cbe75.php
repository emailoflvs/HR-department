<sup>
    <a class="text-black"
       data-controller="fields--popover"
       data-action="click->fields--popover#trigger"
       data-container="body"
       data-toggle="popover"
       tabindex="0"
       data-trigger="focus"
       data-placement="auto"
       data-delay-show="300"
       data-delay-hide="200"
       data-content="<?php echo e($content); ?>">
        <i class="icon-exclamation"></i>
    </a>
</sup>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/partials/fields/popover.blade.php ENDPATH**/ ?>