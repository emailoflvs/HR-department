<?php $__env->startSection('content'); ?>


    
    <h1 class="page-title">
        <i class="voyager-people"></i> Список анкет
    </h1>
    <div id="voyager-notifications"></div>

    <div class="page-content container-fluid">
        <div class="row">
            <div id="dbManager" class="col-md-12">

                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th width="10%">Название</th>
                        
                        <th width="80%">Описание</th>
                        <th width="10%">Комментарии</th>
                        <th width="1%">Статус</th>
                        
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(isset($applicationForms)): ?>
                        <?php $__currentLoopData = $applicationForms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicationForm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="newTableRow">
                                <td>
                                    <a href="/application_form_edit/<?php echo e($applicationForm['id'] ?? ''); ?>"><?php echo e($applicationForm['name'] ?? ''); ?></a>

                                </td>
                                
                                
                                
                                <td>
                                    <?php echo e($applicationForm['details'] ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($applicationForm['comments'] ?? ''); ?>

                                </td>
                                <td>
                                    <?php if(isset($applicationForm['status'])): ?>
                                        <?php if($applicationForm['status']): ?>
                                            активнa
                                        <?php else: ?>
                                            заблокирована
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>


            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/servers/simpatik/resources/views/hr/application_form/application_form_list.blade.php ENDPATH**/ ?>