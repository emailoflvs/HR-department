<div
    data-controller="screen--tabs"
    data-screen--tabs-slug="<?php echo e($templateSlug); ?>"
>
    <div class="nav-tabs-alt mt-2">
        <ul class="nav nav-tabs row" role="tablist">
            <?php $__currentLoopData = $manyForms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a class="nav-link <?php if($loop->first): ?> active <?php endif; ?>"
                       data-action="screen--tabs#setActiveTab"
                       data-target="#tab-<?php echo e(\Illuminate\Support\Str::slug($name)); ?>"
                       id="button-tab-<?php echo e(\Illuminate\Support\Str::slug($name)); ?>"
                       role="tab"
                       data-toggle="tab">
                        <?php echo $name; ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <!-- main content -->
    <section>
        <div class="no-border-xs">
            <div class="tab-content">
                <?php $__currentLoopData = $manyForms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $forms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div role="tabpanel" class="tab-pane <?php if($loop->first): ?> active <?php endif; ?>"
                         id="tab-<?php echo e(\Illuminate\Support\Str::slug($name)); ?>">

                        <div class="py-3">
                            <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $form; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- / main content -->
</div>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/layouts/tabs.blade.php ENDPATH**/ ?>