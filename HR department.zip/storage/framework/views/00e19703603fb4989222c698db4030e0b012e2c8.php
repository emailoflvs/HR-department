<li class="list-group-item py-3 admin-element-item <?php echo e($class ?? ''); ?>">
    <a href="<?php echo e($route); ?>" class="d-block padder">
        <?php if(isset($badge)): ?>
            <b class="badge bg-<?php echo e($badge['class']); ?> pull-right"><?php echo e($badge['data']()); ?></b>
        <?php endif; ?>
        <span class="text-muted"><i class="<?php echo e($icon); ?> pull-right m-t-sm text-lg"></i></span>
        <div class="clear">
            <div><?php echo e(__($label)); ?></div>
            <small class="text-muted"><?php echo e(__($title ?? '')); ?></small>
        </div>
    </a>
</li>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/partials/systems/systemsSubMenu.blade.php ENDPATH**/ ?>