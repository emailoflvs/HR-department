<div class="dropdown-item">
    <div class="custom-control custom-checkbox h-auto w-100">
        <input type="checkbox"
               checked
               class="custom-control-input"
               id="<?php echo e($slug); ?>"
               form="table-columns-select"
               data-action="layouts--table#toggleColumn"
               data-default-hidden="<?php echo e($defaultHidden); ?>"
               data-column="<?php echo e($slug); ?>"
        >
        <label class="custom-control-label d-block w-100 cursor" for="<?php echo e($slug); ?>">
            <?php echo e($title); ?>

        </label>
    </div>
</div>
<?php /**PATH /home/dev/web/crm/vendor/orchid/platform/resources/views/partials/layouts/selectedTd.blade.php ENDPATH**/ ?>