<?php $__env->startComponent($typeForm, get_defined_vars()); ?>

    <div data-controller="fields--utm">
        <div class="input-group mb-3">
            <input <?php call_user_func(function ($attributes) {
                foreach ($attributes as $name => $value) {
                    if (is_null($value)) {
                        continue;
                    }

                    if (is_bool($value) && $value === false) {
                        continue;
                    }
                    if (is_bool($value)) {
                        echo e($name)." ";
                        continue;
                    }

                    if (is_array($value)) {
                        echo json_decode($value)." ";
                        continue;
                    }

                    echo e($name) . '="' . e($value) . '"'." ";
                }
            }, $attributes); ?> data-target="fields--utm.url">
            <div class="input-group-append">
                <button type="button" class="btn btn-default" data-toggle="modal"
                        data-target="#utm-<?php echo e($id); ?>"><?php echo e(__('Generate UTM')); ?></button>
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="utm-<?php echo e($id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header m-b">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <i class="icon-cross icons" aria-hidden="true"></i>
                        </button>
                        <h4 class="modal-title m-b text-black font-thin"
                            id="exampleModalLabel"><?php echo e(__('UTM Generator')); ?></h4>
                    </div>
                    <div class="modal-body">
                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo e(__('Campaign Source')); ?> - <span class="font-bold">utm_source</span></label>
                                    <input type="text" data-target="fields--utm.source" placeholder="google"
                                           class="form-control">
                                    <small
                                        class="form-text text-muted w-b-k"><?php echo e(__('Original referrer: (e.g. google, newsletter)')); ?></small>
                                </div>

                                <div class="form-group">
                                    <label><?php echo e(__('Campaign medium')); ?> - <span class="font-bold">utm_medium</span></label>
                                    <input type="text" data-target="fields--utm.medium" placeholder="cpc"
                                           class="form-control">
                                    <small class="form-text text-muted w-b-k"><?php echo e(__('Marketing medium: (e.g. cpc, ppc, banner, email)')); ?></small>
                                </div>

                                <div class="form-group">
                                    <label><?php echo e(__('Campaign name')); ?> - <span class="font-bold">utm_campaign</span></label>
                                    <input type="text" data-target="fields--utm.campaign" pattern="[a-zA-Z0-9]+"
                                           placeholder="sleeping_beds"
                                           class="form-control">
                                    <small class="form-text text-muted w-b-k"><?php echo e(__('Product, promo code, or slogan (e.g. spring_sale)')); ?></small>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo e(__('Campaign term')); ?> - <span class="font-bold">utm_term</span></label>
                                    <input type="text" data-target="fields--utm.term" placeholder="Golf ball"
                                           class="form-control">
                                    <small class="form-text text-muted w-b-k"><?php echo e(__('Paid keywords: (e.g. running+shoes)')); ?></small>
                                </div>

                                <div class="form-group">
                                    <label><?php echo e(__('Campaign content')); ?> - <span
                                                class="font-bold">utm_content</span></label>
                                    <input type="text" data-target="fields--utm.content" placeholder="cpc"
                                           class="form-control">
                                    <small class="form-text text-muted w-b-k"><?php echo e(__('Ad-specific content used to differentiate ads')); ?>

                                    </small>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-link" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                        <button type="button" data-action="fields--utm#generate" data-dismiss="modal"
                                class="btn btn-default"><?php echo e(__('Generate URL')); ?></button>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php if (isset($__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d)): ?>
<?php $component = $__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d; ?>
<?php unset($__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/fields/utm.blade.php ENDPATH**/ ?>