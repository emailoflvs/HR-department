<nav class="navbar navbar-default navbar-fixed-top navbar-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <button class="hamburger btn-link">
                <span class="hamburger-inner"></span>
            </button>
            <ol class="breadcrumb hidden-xs">
                <li class="active"><i class="voyager-boat"></i> Панель управления</li>
            </ol>
            <ol class="breadcrumb hidden-xs">
                <li class="active"><i class="voyager-search"></i>
                    <input name="search" placeholder="Поиск"  >
                </li>
            </ol>

        </div>
        <ul class="nav navbar-nav  navbar-right ">
            <li class="dropdown profile">
                <a href="#" class="dropdown-toggle text-right" data-toggle="dropdown" role="button"
                   aria-expanded="false"><img src="/storage/<?php echo Auth::user()->getAttributes()['avatar']; ?>"
                                              class="profile-img"> <span
                        class="caret"></span></a>
                <ul class="dropdown-menu dropdown-menu-animated">
                    <li class="profile-img">
                        <img src="/storage/<?php echo Auth::user()->getAttributes()['avatar']; ?>"
                             class="profile-img">
                        <div class="profile-body">
                            <h5><?php echo Auth::user()->getAttributes()['name']; ?></h5>
                            <h6><?php echo Auth::user()->getAttributes()['email']; ?></h6>
                        </div>
                    </li>






                    <?php if(Auth::user()->hasRole('admin') || Auth::user()->hasRole('developer')): ?>
                        <li class="divider"></li>
                        <li class="class-full-of-rum">
                            <a href="/admin">
                                <i class="voyager-person"></i>
                                Админка
                            </a>
                        </li>
                    <?php endif; ?>
                    <li>
                        <a href="/" target="_blank">
                            <i class="voyager-home"></i>
                            Главная
                        </a>
                    </li>
                    <li>
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-danger btn-block">
                                <i class="voyager-power"></i>
                                Выход
                            </button>
                        </form>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</nav>









<div class="side-menu sidebar-inverse">
    <nav class="navbar navbar-default" role="navigation">
        <div class="side-menu-container">
            <div class="navbar-header">
                <a class="navbar-brand" href="http://simpatik/admin">
                    <div class="logo-icon-container">
                        <img src="/admin/voyager-assets?path=images%2Flogo-icon-light.png" alt="Logo Icon">
                    </div>
                    <div class="title"><?php echo setting('site.title'); ?></div>
                </a>
            </div>

            <div class="panel widget center bgimage"
                 style=" background-size: cover; background-position: 0px;">

                <div class="dimmer"></div>








            </div>

        </div>
        <div id="adminmenu">
            <ul class="nav navbar-nav">
                <li class=""><a target="_self" href="/">
                        <span class="icon voyager-boat"></span>
                        <span class="title">Основные</span></a>
                </li>
                <li class="">
                    <a target="_self" href="/client">
                        <span class="icon voyager-person"></span>
                        <span class="title">Карта клиента</span></a>
                </li>
                <li class="">
                    <a target="_self" href="/clients">
                        <span class="icon voyager-people"></span> <span class="title">Список клиентов</span></a>
                </li>
                <li class="">
                    <a target="_self" href="/orders">
                        <span class="icon voyager-basket"></span>
                        <span class="title">Список заказов</span></a>
                </li>
                <li class="">
                    <a target="_self" href="/search"><span class="icon voyager-search"></span>
                        <span class="title">Поиск</span></a></li>


                <li class="">
                    <a target="_self" href="/roles">
                        <span class="icon voyager-lock"></span> <span class="title">Заказы СМС предоплата</span></a>
                </li>
                <li class="dropdown"><a target="_self" href="#5-dropdown-element" data-toggle="collapse"
                                        aria-expanded="false"><span class="icon voyager-tools"></span> <span
                            class="title">Отчеты</span></a>
                    <div id="5-dropdown-element" class="panel-collapse collapse ">
                        <div class="panel-body">
                            <ul class="nav navbar-nav">
                                <li class=""><a target="_self" href="http://simpatik/admin/menus"><span
                                            class="icon voyager-list"></span> <span
                                            class="title">Создать отчет</span></a> <!----></li>
                                <li class=""><a target="_self" href="http://simpatik/admin/database"><span
                                            class="icon voyager-data"></span> <span class="title">Список отчетов</span></a>
                                    <!----></li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li class=""><a target="_self" href="http://simpatik/admin/settings"><span
                            class="icon voyager-settings"></span> <span class="title">Settings</span></a> <!----></li>
            </ul>
        </div>




    </nav>
</div>























<script>
    (function () {
        var appContainer = document.querySelector('.app-container'),
            sidebar = appContainer.querySelector('.side-menu'),
            navbar = appContainer.querySelector('nav.navbar.navbar-top'),
            loader = document.getElementById('voyager-loader'),
            hamburgerMenu = document.querySelector('.hamburger'),
            sidebarTransition = sidebar.style.transition,
            navbarTransition = navbar.style.transition,
            containerTransition = appContainer.style.transition;

        sidebar.style.WebkitTransition = sidebar.style.MozTransition = sidebar.style.transition =
            appContainer.style.WebkitTransition = appContainer.style.MozTransition = appContainer.style.transition =
                navbar.style.WebkitTransition = navbar.style.MozTransition = navbar.style.transition = 'none';

        if (window.innerWidth > 768 && window.localStorage && window.localStorage['voyager.stickySidebar'] == 'true') {
            appContainer.className += ' expanded no-animation';
            loader.style.left = (sidebar.clientWidth / 2) + 'px';
            hamburgerMenu.className += ' is-active no-animation';
        }

        navbar.style.WebkitTransition = navbar.style.MozTransition = navbar.style.transition = navbarTransition;
        sidebar.style.WebkitTransition = sidebar.style.MozTransition = sidebar.style.transition = sidebarTransition;
        appContainer.style.WebkitTransition = appContainer.style.MozTransition = appContainer.style.transition = containerTransition;
    })();
</script>
<?php /**PATH /home/servers/simpatik/resources/views/navigation/menu.blade.php ENDPATH**/ ?>
