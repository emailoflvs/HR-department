<td class="text-<?php echo e($align); ?> <?php if(!$width): ?> text-truncate <?php endif; ?>" data-column="<?php echo e($slug); ?>">
    <div style="width:<?php echo e(ctype_digit($width) ? $width . 'px' : $width); ?>">
        <?php if(isset($render)): ?>
            <?php echo $value; ?>

        <?php else: ?>
            <?php echo e($value); ?>

        <?php endif; ?>
    </div>
</td>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/partials/layouts/td.blade.php ENDPATH**/ ?>