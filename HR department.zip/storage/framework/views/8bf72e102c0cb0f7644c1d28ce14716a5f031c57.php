<?php echo $__env->make('hr.application_form.html.application_form_html_div_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h5><?php echo e($questions[$question]['question'] ?? ''); ?>

    <span style="color: red">*</span></h5>
<h5><?php echo e($questions[$question]['details'] ?? ''); ?></h5>
<textarea name="<?php echo e($question); ?>" required class="form-control" rows="4"></textarea>
<?php echo $__env->make('hr.application_form.html.application_form_html_div_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/servers/simpatik/resources/views/hr/application_form/html/application_form_html_textarea.blade.php ENDPATH**/ ?>