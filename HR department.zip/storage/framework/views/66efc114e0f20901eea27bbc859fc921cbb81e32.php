<?php if(session()->has(\Orchid\Alert\Alert::SESSION_MESSAGE)): ?>
    <div class="alert alert-<?php echo e(session(\Orchid\Alert\Alert::SESSION_LEVEL)); ?>">
        <button type="button"
                class="close"
                data-dismiss="alert"
                aria-hidden="true">&times;
        </button>
        <?php echo session(\Orchid\Alert\Alert::SESSION_MESSAGE); ?>


        <?php echo $__env->yieldContent('flash_notification.sub_message'); ?>
    </div>
<?php endif; ?>

<?php if(empty(!$errors->count())): ?>
    <div class="alert alert-danger" role="alert">
        <strong><?php echo e(__('Oh snap!')); ?></strong>
        <?php echo e(__('Change a few things up and try submitting again.')); ?>

        <ul class="m-t-xs">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/partials/alert.blade.php ENDPATH**/ ?>