<div class="w-100 border v-center border-dashed my-3"
     style="min-height: 250px;">
    <h2 class="text-muted center font-thin">Dummy</h2>
</div>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/dummy/block.blade.php ENDPATH**/ ?>