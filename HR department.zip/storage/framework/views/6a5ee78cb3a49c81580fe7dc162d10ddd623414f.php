<?php if(isset($title)): ?>
    <div class="hidden-folded padder m-t-xs m-b-xs text-muted text-xs m-l"><?php echo e(__($title)); ?></div>
<?php endif; ?>
<a href="<?php echo e($route ?? '#'); ?>" class="dropdown-item">

    <span class="col-auto mr-auto no-padder">
        <i class="<?php echo e($icon); ?> mr-2"></i>
        <?php echo e(__($label)); ?>

    </span>

    <?php if(isset($badge)): ?>
        <span class="col-auto no-padder">
                <b class="badge bg-<?php echo e($badge['class']); ?>"><?php echo e($badge['data']()); ?></b>
        </span>
    <?php endif; ?>
</a>
<?php /**PATH /home/dev/web/crm/vendor/orchid/platform/resources/views/partials/dropdownMenu.blade.php ENDPATH**/ ?>