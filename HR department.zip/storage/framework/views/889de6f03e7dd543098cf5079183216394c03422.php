<div class="pull-right text-center pl-3" data-turbolinks-permanent>
    <a href="<?php echo e(route('platform.notifications')); ?>"
       class="nav-link icon no-padder"
       data-controller="layouts--notification"
       data-layouts--notification-count="<?php echo e(count($notifications)); ?>"
       data-layouts--notification-url="<?php echo e(route('platform.api.notifications')); ?>"
       data-layouts--notification-method="post"
       data-layouts--notification-interval="60000"
    >
        <i class="icon-bell"></i>

        <span class="badge badge-sm up bg-danger text-white" data-target="layouts--notification.badge"></span>
    </a>
</div>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/partials/notificationProfile.blade.php ENDPATH**/ ?>