<?php $__env->startSection('content'); ?>

    <div class="analytics-container" align="center">
        <div class="content center">
            <form class="page-content container-fluid" align="left" action="/hr_person_edit/<?php echo e($person->id); ?>"
                  method="get">

                <?php echo $__env->make('hr.application_form.html.application_form_html_div_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <h3>Анкета кандидата <a href="/hr_person_edit/<?php echo e($person->id); ?>">
                        <?php echo e($person->surname); ?> <?php echo e($person->name); ?></a></h3>

                <?php echo $__env->make('hr.application_form.html.application_form_html_div_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('hr.application_form.html.application_form_html_div_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                
    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                $name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                $filiation], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                                $phoneNumber], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                                $years], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                                $hrEmploymentRule], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                                $desiredSalaryFirst], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                                $desiredSalarySecond], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    
    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                                $infoSource], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                                $infoSourceName], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    

    <?php echo $__env->make('hr.application_form.html.application_form_html_show_radio', ['question'=>
                                                                    $children ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                $desiredWorkTime], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    
    
    

    
    
    
    


    

    <?php echo $__env->make('hr.application_form.html.application_form_html_show_radio', ['question'=>
                                                                $operatorExperience ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                $opinion ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    
    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                $workLocationRating], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    
    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                $raisingCareerRating], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                    $salaryImportant], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                    $professionalPersonalDevelopment], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                    $prestigeWork], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                    $ruToUaTranslation], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                    $computerSkills], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                    $computerSkillsTurnOff], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                    $computerSkillsPusk], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                    $uaToRuTranslation], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                    $hrPersonDocuments], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('hr.application_form.html.application_form_html_show_part', ['question'=>
                                                                                $hrCompTechnicalRequirements], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                
                




                
                
                
                

                
                <input type="submit" value="Вернуться к кандидату" class="btn btn-primary pull-right">
            </form>

    


    
    
    
    
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.application_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/servers/simpatik/resources/views/hr/application_form/application_form_show.blade.php ENDPATH**/ ?>