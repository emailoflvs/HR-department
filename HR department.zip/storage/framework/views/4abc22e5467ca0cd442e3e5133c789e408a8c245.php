<?php $__env->startComponent($typeForm, get_defined_vars()); ?>
    <div class="row" data-controller="fields--datetime"
         data-fields--datetime-allow-input="true"
         data-fields--datetime-range="#end_<?php echo e(\Illuminate\Support\Str::slug($attributes['name'])); ?>">
        <div class="col-md-6 pr-1">
            <div class="form-group">
                <input type="text"
                       <?php if(isset($attributes['form'])): ?> form="<?php echo e($attributes['form'] ?? null); ?>" <?php endif; ?>
                       name="<?php echo e($attributes['name']); ?>[start]"
                       id='start_<?php echo e($attributes['name']); ?>'
                       data-target="fields--datetime.instance"
                       value="<?php echo e($attributes['value']['start'] ?? null); ?>"
                       class="form-control">
            </div>
        </div>

        <div class="col-md-6 pl-1">
            <div class="form-group">
                <input type="text"
                       <?php if(isset($attributes['form'])): ?> form="<?php echo e($attributes['form'] ?? null); ?>" <?php endif; ?>
                       name="<?php echo e($attributes['name']); ?>[end]"
                       data-target="fields--datetime.instance"
                       id='end_<?php echo e(\Illuminate\Support\Str::slug($attributes['name'])); ?>'
                       value="<?php echo e($attributes['value']['end'] ?? null); ?>"
                       class="form-control">
            </div>
        </div>
    </div>
<?php if (isset($__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d)): ?>
<?php $component = $__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d; ?>
<?php unset($__componentOriginal022c3adc7a3ddf487615f02d89190e3aa95e3b2d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/servers/simpatik/vendor/orchid/platform/resources/views/fields/range.blade.php ENDPATH**/ ?>