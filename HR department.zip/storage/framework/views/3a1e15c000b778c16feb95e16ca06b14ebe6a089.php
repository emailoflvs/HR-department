<div class="form-group">
    <?php if(isset($title)): ?>
        <label for="<?php echo e($id); ?>" class="form-label"><?php echo e($title); ?>

            <?php if(isset($attributes['required']) && $attributes['required']): ?>
                <sup class="text-danger">*</sup>
            <?php endif; ?>
            <?php echo $__env->renderWhen(isset($popover),'platform::partials.fields.popover',[
                'content' => $popover ?? ''
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
        </label>
    <?php endif; ?>

    <?php echo e($slot); ?>


    <?php if($errors->has($oldName)): ?>
        <div class="invalid-feedback d-block">
            <small><?php echo e($errors->first($oldName)); ?></small>
        </div>
    <?php elseif(isset($help)): ?>
        <small class="form-text text-muted"><?php echo $help; ?></small>
    <?php endif; ?>
</div>
<?php if(isset($hr)): ?>
    <div class="line line-dashed border-bottom line-lg"></div>
<?php endif; ?>
<?php /**PATH /home/dev/web/crm/vendor/orchid/platform/resources/views/partials/fields/vertical.blade.php ENDPATH**/ ?>