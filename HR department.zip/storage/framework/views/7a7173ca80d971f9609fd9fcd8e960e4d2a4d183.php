<table class="table table-bordered" style="width: 100%;" width="50%">
    <thead>
    <tr>
        <th width="30%">Статус:</th>
        <th width="70%">
            Комментарии:
        </th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>
            <?php if(isset($hrPersonStatuses)): ?>
                <?php if(isset($lastInterview)): ?>
                    Потенциальный статус:
                    <table class="table table-bordered" style="width: 100%;">
                        <thead>
                        <tr>
                            <th width="10%">Проведено:</th>
                            <th width="50%">Статус:</th>
                            <th width="30%">Комментарий</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(isset($lastInterview['inviteResult'])): ?>
                            <tr class="newTableRow">
                                <td>
                                    <?php echo e($lastInterview['happenInterviewDate'] ?? ''); ?>  <?php echo e($lastInterview['happenInterviewTime'] ?? ''); ?>

                                </td>
                                <td>
                                    <?php if($lastInterview['inviteResult'] == 'invite'): ?>
                                        <span class="btn btn-success"
                                              style="cursor:text;">Приглашен на собеседование</span>

                                        <?php if(isset($lastInterview['timetable'])): ?>
                                            <br>График работы:
                                            <?php if(isset($timetables)): ?>
                                                <?php $__currentLoopData = $timetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timetable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($lastInterview['timetable'] == $timetable->id): ?>
                                                            <?php echo e($timetable->timetable); ?>

                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                        <?php endif; ?>
                                        <?php if(isset($lastInterview['hrSpecialization'])): ?>
                                                <br>Направление работы:
                                                <?php if(isset($hrSpecializations)): ?>
                                                <?php $__currentLoopData = $hrSpecializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hrSpecialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($lastInterview['hrSpecialization'] == $hrSpecialization->id): ?>
                                                        <?php echo e($hrSpecialization->name); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if($lastInterview['inviteResult'] == 'clarification'): ?>
                                        <span class="btn btn-warning" style="cursor:text;">На уточнении</span>
                                        <?php if(isset($lastInterview['inviteClarification']->reason)): ?>
                                            <br>Причина: <?php echo e($lastInterview['inviteClarification']->reason); ?>

                                        <?php endif; ?>
                                        <?php if(isset($lastInterview['inviteClarificationDetails'])): ?>
                                            <br>Подробнее: <?php echo e($lastInterview['inviteClarificationDetails']); ?>

                                        <?php endif; ?>

                                        <?php if(isset($lastInterview['planInviteClarificationRecallDate'])): ?>
                                            <br>Перезвонить:
                                            <input
                                                id="planInviteClarificationRecallDate<?php echo e($lastInterview['id'] ?? ''); ?>"
                                                type="date"
                                                name="planInviteClarificationRecallDate_<?php echo e($lastInterview['id'] ?? ''); ?>"
                                                value="<?php echo e($lastInterview['planInviteClarificationRecallDate'] ?? date("yy-m-d")); ?>">

                                            <select
                                                id="planInviteClarificationRecallTime<?php echo e($lastInterview['id'] ?? ''); ?>"
                                                name="planInviteClarificationRecallTime_<?php echo e($lastInterview['id'] ?? ''); ?>">
                                                <option></option>
                                                <option value="09:00">09:00</option>
                                                <option value="09:30">09:30</option>
                                                <?php for($i = 10; $i < 19; $i++): ?>
                                                    <option value="<?php echo e($i); ?>:00"><?php echo e($i); ?>:00</option>
                                                    <option value="<?php echo e($i); ?>:30"><?php echo e($i); ?>:30</option>
                                                <?php endfor; ?>
                                            </select>
                                            <script>
                                                $('#planInviteClarificationRecallTime<?php echo e($lastInterview['id'] ?? ''); ?> option[value="<?php echo e($interview['planInviteClarificationRecallTime'] ?? ''); ?>"]')
                                                    .prop('selected', true);
                                            </script>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if($lastInterview['inviteResult'] == 'refusing'): ?>
                                        <span class="btn btn-danger" style="cursor:text;">Отказ</span>

                                        <?php if(isset($lastInterview['inviteRefusingReasonCompany'])): ?>
                                            <br>Со стороны компании: <?php echo e($lastInterview['inviteRefusingReasonCompany']); ?>

                                        <?php endif; ?>
                                        <?php if(isset($lastInterview['inviteRefusingReasonCompanyDetails'])): ?>
                                            <br>Со стороны
                                            компании: <?php echo e($lastInterview['inviteRefusingReasonCompanyDetails']); ?>

                                        <?php endif; ?>

                                        <?php if(isset($lastInterview['inviteRefusingReasonPerson'])): ?>
                                            <br>Со стороны компании: <?php echo e($lastInterview['inviteRefusingReasonPerson']); ?>

                                        <?php endif; ?>
                                        <?php if(isset($lastInterview['inviteRefusingReasonPersonDetails'])): ?>
                                            <br>Со стороны
                                            кандидата: <?php echo e($lastInterview['inviteRefusingReasonPersonDetails']); ?>

                                        <?php endif; ?>
                                        
                                    <?php endif; ?>

                                </td>
                                <td>
                                    <?php if(isset($lastInterview['interviewСomments'])): ?>
                                        <input type="text" name="interviewComments_<?php echo e($lastInterview['id'] ?? ''); ?>"
                                               value="<?php echo e($lastInterview['interviewСomments'] ?? ''); ?>"
                                               class="form-control">
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                        
                        </tbody>
                    </table>

                <?php endif; ?>







                Выбранный менеджером:
                <select name="hrPersonStatuse_<?php echo e($hrPersonStatuse['id'] ?? ''); ?>"
                        id="hrPersonStatuse<?php echo e($hrPersonStatuse['id'] ?? ''); ?>"
                        class="form-control" width="10px"
                        width="100px"
                >
                    <option value="">
                        -
                    </option>
                    <?php $__currentLoopData = $hrPersonStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hrPersonStatuse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <option value="<?php echo e($hrPersonStatuse['id'] ?? ''); ?>">
                            <?php echo e($hrPersonStatuse['displayName'] ?? ''); ?>

                        </option>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <script>
                    $('#hrPersonStatuse<?php echo e($hrPersonStatuse['id'] ?? ''); ?> option[value="<?php echo e($hrPersonStatuse['id'] ?? ''); ?>"]')
                        .prop('selected', true);
                </script>
            <?php endif; ?>
        </td>
        <td>
            <div class="col-md-7 form-group">
                <textarea rows="2" cols="50" name="history" class="form-control"><?php echo e($person->history ?? ''); ?></textarea>
            </div>
            
            

        </td>
    </tr>
    </tbody>
</table>

<?php /**PATH /home/servers/simpatik/resources/views/hr/person_info_form_invite.blade.php ENDPATH**/ ?>