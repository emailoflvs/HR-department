@php
    session_start();
@endphp<!DOCTYPE html>
<html lang="ru" dir="ltr">
<head>
    <title>{!! setting('site.title') !!}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}"/>
    <meta name="assets-path" content="/admin/voyager-assets"/>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">

    <!-- Favicon -->
    <link rel="shortcut icon" href="/admin/voyager-assets?path=images%2Flogo-icon.png" type="image/png">


    <!-- App CSS -->
    <link rel="stylesheet" href="/admin/voyager-assets?path=css%2Fapp.css">


    <!-- Few Dynamic Styles -->
    <style type="text/css">
        .voyager .side-menu .navbar-header {
            background: #22A7F0;
            border-color: #22A7F0;
        }

        .widget .btn-primary {
            border-color: #22A7F0;
        }

        .widget .btn-primary:focus, .widget .btn-primary:hover, .widget .btn-primary:active, .widget .btn-primary.active, .widget .btn-primary:active:focus {
            background: #22A7F0;
        }

        .voyager .breadcrumb a {
            color: #22A7F0;
        }
    </style>
</head>

<body class="voyager ">

<div class="app-container">
    <div class="fadetoblack visible-xs"></div>
    <div class="row content-container">
        @auth
            @include('navigation.menu')
        @endauth
        <script>
            (function () {
                var appContainer = document.querySelector('.app-container'),
                    sidebar = appContainer.querySelector('.side-menu'),
                    navbar = appContainer.querySelector('nav.navbar.navbar-top'),
                    loader = document.getElementById('voyager-loader'),
                    hamburgerMenu = document.querySelector('.hamburger'),
                    sidebarTransition = sidebar.style.transition,
                    navbarTransition = navbar.style.transition,
                    containerTransition = appContainer.style.transition;

                sidebar.style.WebkitTransition = sidebar.style.MozTransition = sidebar.style.transition =
                    appContainer.style.WebkitTransition = appContainer.style.MozTransition = appContainer.style.transition =
                        navbar.style.WebkitTransition = navbar.style.MozTransition = navbar.style.transition = 'none';

                if (window.innerWidth > 768 && window.localStorage && window.localStorage['voyager.stickySidebar'] == 'true') {
                    appContainer.className += ' expanded no-animation';
                    loader.style.left = (sidebar.clientWidth / 2) + 'px';
                    hamburgerMenu.className += ' is-active no-animation';
                }

                navbar.style.WebkitTransition = navbar.style.MozTransition = navbar.style.transition = navbarTransition;
                sidebar.style.WebkitTransition = sidebar.style.MozTransition = sidebar.style.transition = sidebarTransition;
                appContainer.style.WebkitTransition = appContainer.style.MozTransition = appContainer.style.transition = containerTransition;
            })();
        </script>
        <!-- Main Content -->
        <div class="container-fluid">
            <div class="side-body padding-top">


                {{--    <!-- Main Content -->--}}
                {{--        <div class="container-fluid">--}}


                @yield('content')


                <div class="modal modal-success fade" tabindex="-1" id="place-out_modal" role="dialog">
                    <div class="modal-dialog">
                        <form name="working" class="modal-content" action="/working" id="place-out_form" method="POST">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                        aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title"><i class="voyager-plus"></i>Причина выхода</h4>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <br>
{{--                                    <label for="name">Причина выхода</label>--}}
                                    <select name="out-reason" class="form-control input-sm" id="out-reason">
                                    @php
                                        use App\WorkingStatus;
                                        foreach (WorkingStatus::where ('type','=',0)->get() as $item)
                                            echo "<option value='".$item->getAttributes()['id']."'>".$item->getAttributes()['name']."</option>";
                                    @endphp
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                {{ csrf_field() }}
                                <input type="submit" class="btn btn-success pull-right"
                                       value="Выйти">
                                <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Отмена</button>
                            </div>
                            <input type="hidden" name="working_status" value="0">
                        </form><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->


                @section('javascript')
                <!-- DataTables -->
                    <script>
                        $(document).ready(function () {
                            $('#dataTable').DataTable({"order": []});
                        });

                        $('.place-out').on('click', function (e) {
                            var form = $('#place-out_form')[0];

                            $('#place-out_modal').modal('show');
                        });

                        $('.page-title').on('click', '.install', function (e) {
                            var form = $('#install_form')[0];

                            $('#install_modal').modal('show');
                        });

                        $('td').on('click', '.delete', function (e) {
                            var form = $('#delete_form')[0];

                            form.action = parseActionUrl(form.action, $(this).data('id'));

                            $('#delete_modal').modal('show');
                        });

                    </script>
                @stop

                @include('voyager::partials.app-footer')

                <!-- Javascript Libs -->


                    <script type="text/javascript" src="{{ voyager_asset('js/app.js') }}"></script>

                    <script>
                            @if(Session::has('alerts'))
                        let alerts = {!! json_encode(Session::get('alerts')) !!};
                        helpers.displayAlerts(alerts, toastr);
                        @endif

                        @if(Session::has('message'))

                        // TODO: change Controllers to use AlertsMessages trait... then remove this
                        var alertType = {!! json_encode(Session::get('alert-type', 'info')) !!};
                        var alertMessage = {!! json_encode(Session::get('message')) !!};
                        var alerter = toastr[alertType];

                        if (alerter) {
                            alerter(alertMessage);
                        } else {
                            toastr.error("toastr alert-type " + alertType + " is unknown");
                        }
                        @endif
                    </script>
                @include('voyager::media.manager')
                @yield('javascript')
                @stack('javascript')
                @if(!empty(config('voyager.additional_js')))<!-- Additional Javascript -->
                    @foreach(config('voyager.additional_js') as $js)<script type="text/javascript" src="{{ asset($js) }}"></script>@endforeach
@endif

</body>
</html>
