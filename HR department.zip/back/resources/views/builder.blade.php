{{--@extends('voyager::master')--}}
@extends('layouts.app')

@section('content')

    {{--    <div class="page-content">--}}
    {{--        <div class="alerts">--}}
    {{--        </div>--}}
    {{--        <div class="analytics-container">--}}
    {{--            --}}{{--                        <p style="border-radius:4px; padding:20px; background:#fff; margin:0; color:#999; text-align:center;">--}}
    {{--            <h3 style="border-radius:4px; padding:20px; background:#fff; margin:0; color:#999; text-align:center;">--}}
    {{--                Основной контент--}}
    {{--            </h3>--}}
    {{--        </div>--}}
    {{--    </div>--}}

@stop


